const utils = require('myscripts_utils');

function execute(task) {
	Fptr.setParam(Fptr.LIBFPTR_PARAM_DATA_TYPE, Fptr.LIBFPTR_DT_SHIFT_STATE);
	if (Fptr.queryData() < 0) {
		return Fptr.error();
	}

    var shiftState;
    switch (Fptr.getParamInt(Fptr.LIBFPTR_PARAM_SHIFT_STATE)) {
        case Fptr.LIBFPTR_SS_CLOSED:
            shiftState = "closed";
            break;
        case Fptr.LIBFPTR_SS_OPENED:
            shiftState = "opened";
            break;
        case Fptr.LIBFPTR_SS_EXPIRED:
            shiftState = "expired";
            break;
        default:
            break;
    }
    return Fptr.ok({
        shiftStatus: {
            number: Fptr.getParamInt(Fptr.LIBFPTR_PARAM_SHIFT_NUMBER),
            expiredTime: utils.dateToIsoString(Fptr.getParamDateTime(Fptr.LIBFPTR_PARAM_DATE_TIME)),
            state: shiftState
        }
    });
}
