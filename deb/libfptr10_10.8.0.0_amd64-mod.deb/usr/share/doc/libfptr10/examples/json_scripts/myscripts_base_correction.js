const utils = require('myscripts_utils');
const items = require('myscripts_items');
const validators = require('myscripts_validators');
const reggie = /^(\d{4}).(\d{2}).(\d{2})$/;

function exitWithCancelation(e) {
    Fptr.cancelReceipt();
    Fptr.enableAutoCliche();
    return e;
}

function validateNewCorrection(task) {
    if (!validators.isMissing(validators.mustObjectOrMissing(task.operator, "operator"))) {
        validators.mustObject(task.operator, "operator");
        validators.mustString(task.operator.name, "operator.name");
        validators.mustStringOrMissing(task.operator.vatin, "operator.vatin");
    }

    validators.mustStringOrMissingValues(task.correctionType, "correctionType", ["self", "instruction"]);
    validators.mustStringOrMissing(task.correctionBaseName, "correctionBaseName");
    validators.mustStringOrMissing(task.correctionBaseNumber, "correctionBaseNumber");
    var dateString = validators.mustStringOrMissing(task.correctionBaseDate, "correctionBaseDate");
    if (!validators.isMissing(dateString)) {
        if (!reggie.test(dateString)) {
            throw new validators.InvalidJsonValueError("correctionBaseDate", dateString);
        }
    }

    validators.mustBooleanOrMissing(task.ignoreNonFiscalPrintErrors, "ignoreNonFiscalPrintErrors");
    validators.mustBooleanOrMissing(task.electronically, "electronically");
    validators.mustBooleanOrMissing(task.useVAT18, "useVAT18");
    validators.mustStringOrMissingValues(task.taxationType, "taxationType", Object.keys(utils.TAXATION_TYPES));
    validators.mustStringOrMissing(task.paymentsPlace, "paymentsPlace");
    validators.mustStringOrMissing(task.machineNumber, "machineNumber");
    validators.mustNumberOrMissing(task.total, "total");

    if (!validators.isMissing(validators.mustObjectOrMissing(task.clientInfo, "clientInfo"))) {
        validators.mustStringOrMissing(task.clientInfo.emailOrPhone, "clientInfo.emailOrPhone");
        validators.mustStringOrMissing(task.clientInfo.vatin, "clientInfo.vatin");
        validators.mustStringOrMissing(task.clientInfo.name, "clientInfo.name");
    }

    if (!validators.isMissing(validators.mustObjectOrMissing(task.companyInfo, "companyInfo"))) {
        validators.mustStringOrMissing(task.companyInfo.email, "companyInfo.email");
    }

    if (!validators.isMissing(validators.mustObjectOrMissing(task.agentInfo, "agentInfo"))) {
        validators.validateAgentInfo(task.agentInfo);
    }

    if (!validators.isMissing(validators.mustObjectOrMissing(task.supplierInfo, "supplierInfo"))) {
        validators.validateSupplierInfo(task.supplierInfo);
    }

    var itemsArray = validators.mustArray(task.items, "items");
    for (var i = 0; i < itemsArray.length; ++i) {
        try {
            var type = validators.mustString(itemsArray[i].type, "type");
            if (type === "text") {
                validators.validateTextItem(itemsArray[i]);
            } else if (type === "barcode") {
                validators.validateBarcodeItem(itemsArray[i]);
            } else if (type === "pictureFromMemory") {
                validators.validatePictureFromMemoryItem(itemsArray[i]);
            } else if (type === "position") {
                validators.validatePositionItem(itemsArray[i]);
            } else if (type === "userAttribute") {
                validators.validateUserAttributeItem(itemsArray[i]);
            } else if (type === "additionalAttribute") {
                validators.validateAdditionalAttributeItem(itemsArray[i]);
            } else if (type === "pixels") {
                validators.validatePixelsItem(itemsArray[i]);
            }
        } catch (e) {
            if (e.name === "InvalidJsonValueError") {
                throw new validators.InvalidJsonValueError(utils.makeDotPath("items[" + i + "]", e.path), e.value);
            } else if (e.name === "InvalidJsonTypeError") {
                throw new validators.InvalidJsonTypeError(utils.makeDotPath("items[" + i + "]", e.path), e.expectedType);
            } else if (e.name === "JsonValueNotFoundError") {
                throw new validators.JsonValueNotFoundError(utils.makeDotPath("items[" + i + "]", e.path));
            } else {
                throw e;
            }
        }
    }

    var paymentsArray = validators.mustArray(task.payments, "payments");
    for (var i = 0; i < paymentsArray.length; ++i) {
        try {
            try {
                validators.mustStringValues(paymentsArray[i].type, "type", Object.keys(utils.PAYMENT_TYPES));
            } catch (e) {
                if (e.name === "InvalidJsonValueError") {
                    if (isNaN(parseInt(paymentsArray[i].type, 10)))
                        throw e;
                } else {
                    throw e;
                }
            }
            validators.mustNumber(paymentsArray[i].sum, "sum");

            var printItems = validators.mustArrayOrMissing(paymentsArray[i].printItems, "printItems");
            if (!validators.isMissing(printItems)) {
                for (var j = 0; j < printItems.length; ++j) {
                    try {
                        var type = validators.mustString(printItems[j].type, "type");
                        if (type === "text") {
                            validators.validateTextItem(printItems[j]);
                        } else if (type === "barcode") {
                            validators.validateBarcodeItem(printItems[j]);
                        } else if (type === "pictureFromMemory") {
                            validators.validatePictureFromMemoryItem(printItems[j]);
                        } else if (type === "pixels") {
                            validators.validatePixelsItem(printItems[i]);
                        }
                    } catch (e) {
                        if (e.name === "InvalidJsonValueError") {
                            throw new validators.InvalidJsonValueError(utils.makeDotPath("printItems[" + j + "]", e.path), e.value);
                        } else if (e.name === "InvalidJsonTypeError") {
                            throw new validators.InvalidJsonTypeError(utils.makeDotPath("printItems[" + j + "]", e.path), e.expectedType);
                        } else if (e.name === "JsonValueNotFoundError") {
                            throw new validators.JsonValueNotFoundError(utils.makeDotPath("printItems[" + j + "]", e.path));
                        } else {
                            throw e;
                        }
                    }
                }
            }

        } catch (e) {
            if (e.name === "InvalidJsonValueError") {
                throw new validators.InvalidJsonValueError(utils.makeDotPath("payments[" + i + "]", e.path), e.value);
            } else if (e.name === "InvalidJsonTypeError") {
                throw new validators.InvalidJsonTypeError(utils.makeDotPath("payments[" + i + "]", e.path), e.expectedType);
            } else if (e.name === "JsonValueNotFoundError") {
                throw new validators.JsonValueNotFoundError(utils.makeDotPath("payments[" + i + "]", e.path));
            } else {
                throw e;
            }
        }
    }

    var taxesArray = validators.mustArrayOrMissing(task.taxes, "taxes");
    if (!validators.isMissing(taxesArray)) {
        for (var i = 0; i < taxesArray.length; ++i) {
            try {
                validators.mustStringValues(taxesArray[i].type, "type", Object.keys(utils.TAX_TYPES));
                validators.mustNumber(taxesArray[i].sum, "sum");
            } catch (e) {
                if (e.name === "InvalidJsonValueError") {
                    throw new validators.InvalidJsonValueError(utils.makeDotPath("taxes[" + i + "]", e.path), e.value);
                } else if (e.name === "InvalidJsonTypeError") {
                    throw new validators.InvalidJsonTypeError(utils.makeDotPath("taxes[" + i + "]", e.path), e.expectedType);
                } else if (e.name === "JsonValueNotFoundError") {
                    throw new validators.JsonValueNotFoundError(utils.makeDotPath("taxes[" + i + "]", e.path));
                } else {
                    throw e;
                }
            }
        }
    }

    if (!validators.isMissing(validators.mustArrayOrMissing(task.preItems, "preItems"))) {
        validators.validatePreItems(task.preItems);
    }
    if (!validators.isMissing(validators.mustArrayOrMissing(task.postItems, "postItems"))) {
        validators.validatePostItems(task.postItems);
    }
}

exports.executeNewCorrection = function(task) {
    try {
        validateNewCorrection(task);
    } catch (e) {
        if (e.name === "InvalidJsonValueError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Некорректное значение поля \"" + e.path + "\" (" + e.value + ")")
        } else if (e.name === "InvalidJsonTypeError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Поле \"" + e.path + "\" имеет неверный тип (ожидается \"" + e.expectedType + "\")");
        } else if (e.name === "JsonValueNotFoundError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Поле \"" + e.path + "\" отсутствует");
        } else {
            throw e;
        }
    }

    if (Fptr.cancelReceipt() < 0 && !utils.isNormalCancelError(Fptr.errorCode())) {
        return Fptr.error();
    }

    if (!validators.isMissing(task.operator) && task.operator.name) {
        Fptr.setParam(1021, task.operator.name);
        Fptr.setParam(1203, task.operator.vatin, Fptr.IGNORE_IF_EMPTY);
        if (Fptr.operatorLogin() < 0) {
            return Fptr.error();
        }
    }

    if (!task.electronically) {
        if (!validators.isMissing(task.preItems)) {
            items.executePreItems(task.preItems);
        }
        if (!validators.isMissing(task.postItems)) {
            items.executePostItems(task.postItems);
        }
    }

    var correctionType = undefined;
    switch (task.correctionType) {
        case "self":
            correctionType = 0;
            break;
        case "instruction":
            correctionType = 1;
            break;
    }

    var dateString = task.correctionBaseDate;
    if (!validators.isMissing(dateString)) {
        var dateArray = reggie.exec(dateString);
        var dateObject = new Date();
        dateObject.setUTCFullYear(+dateArray[1]);
        dateObject.setUTCMonth(+dateArray[2] - 1, +dateArray[3]);
        dateObject.setUTCHours(0, 0, 0, 0);
    }

    Fptr.setParam(1177, task.correctionBaseName, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1178, dateObject, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1179, task.correctionBaseNumber, Fptr.IGNORE_IF_EMPTY);
    Fptr.utilFormTlv();
    var tag1174 = Fptr.getParamByteArray(Fptr.LIBFPTR_PARAM_TAG_VALUE);

    Fptr.setParam(Fptr.LIBFPTR_PARAM_RECEIPT_TYPE, utils.CORRECTION_TYPES[task.type]);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_RECEIPT_ELECTRONICALLY, task.electronically, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1173, correctionType, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1174, tag1174, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1055, utils.TAXATION_TYPES[task.taxationType], Fptr.IGNORE_IF_EMPTY);

    if (!validators.isMissing(task.clientInfo)) {
        Fptr.setParam(1008, task.clientInfo.emailOrPhone, Fptr.IGNORE_IF_EMPTY);
        Fptr.setParam(1227, task.clientInfo.name, Fptr.IGNORE_IF_EMPTY);
        Fptr.setParam(1228, task.clientInfo.vatin, Fptr.IGNORE_IF_EMPTY);
    }
    if (!validators.isMissing(task.companyInfo)) {
        Fptr.setParam(1117, task.companyInfo.email, Fptr.IGNORE_IF_EMPTY);
    }
    Fptr.setParam(1187, task.paymentsPlace, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1036, task.machineNumber, Fptr.IGNORE_IF_EMPTY);

    if (!validators.isMissing(task.agentInfo)) {
        if (!validators.isMissing(task.agentInfo.agents)) {
            var agentType = Fptr.LIBFPTR_AT_NONE;
            for (var i = 0; i < task.agentInfo.agents.length; i++) {
                agentType |= utils.AGENT_TYPES[task.agentInfo.agents[i]];
            }
            if (agentType > 0) {
                Fptr.setParam(1057, agentType);
            }
        }

        if (!validators.isMissing(task.agentInfo.moneyTransferOperator)) {
            Fptr.setParam(1005, task.agentInfo.moneyTransferOperator.address, Fptr.IGNORE_IF_EMPTY);
            Fptr.setParam(1016, task.agentInfo.moneyTransferOperator.vatin, Fptr.IGNORE_IF_EMPTY);
            Fptr.setParam(1026, task.agentInfo.moneyTransferOperator.name, Fptr.IGNORE_IF_EMPTY);
            phones = task.agentInfo.moneyTransferOperator.phones;
            for (var i = 0; phones && i < phones.length; i++) {
                Fptr.setParam(1075, task.agentInfo.moneyTransferOperator.phones[i], Fptr.IGNORE_IF_EMPTY);
            }
        }
        if (!validators.isMissing(task.agentInfo.payingAgent)) {
            Fptr.setParam(1044, task.agentInfo.payingAgent.operation, Fptr.IGNORE_IF_EMPTY);
            phones = task.agentInfo.payingAgent.phones;
            for (var i = 0; phones && i < phones.length; i++) {
                Fptr.setParam(1073, task.agentInfo.payingAgent.phones[i], Fptr.IGNORE_IF_EMPTY);
            }
        }
        if (!validators.isMissing(task.agentInfo.receivePaymentsOperator)) {
            phones = task.agentInfo.receivePaymentsOperator.phones;
            for (var i = 0; phones && i < phones.length; i++) {
                Fptr.setParam(1074, task.agentInfo.receivePaymentsOperator.phones[i], Fptr.IGNORE_IF_EMPTY);
            }
        }
    }
    if (!validators.isMissing(task.supplierInfo)) {
        phones = task.supplierInfo.phones;
        for (var i = 0; phones && i < phones.length; i++) {
            Fptr.setParam(1171, task.supplierInfo.phones[i], Fptr.IGNORE_IF_EMPTY);
        }
    }

    var res = Fptr.openReceipt();
    var shiftAutoOpened = Fptr.getParamBool(Fptr.LIBFPTR_PARAM_SHIFT_AUTO_OPENED);
    if (res < 0) {
        return exitWithCancelation(Fptr.error());
    }

    var total = 0;
    for (var i = 0; i < task.items.length; i++) {
        if (task.items[i].type === "position") {
            e = items.executePosition(task.items[i]);
            if (e.isError) {
                return exitWithCancelation(e);
            }
            total += Number(task.items[i].amount.toFixed(2));
        } else if (task.items[i].type === "text") {
            e = items.executeText(task.items[i]);
            if (e.isError && !task.ignoreNonFiscalPrintErrors) {
                return exitWithCancelation(Fptr.error());
            }
        } else if (task.items[i].type === "barcode") {
            e = items.executeBarcode(task.items[i]);
            if (e.isError && !task.ignoreNonFiscalPrintErrors) {
                return exitWithCancelation(Fptr.error());
            }
        } else if (task.items[i].type === "pictureFromMemory") {
            e = items.executePictureFromMemory(task.items[i]);
            if (e.isError && !task.ignoreNonFiscalPrintErrors) {
                return exitWithCancelation(Fptr.error());
            }
        } else if (task.items[i].type === "userAttribute") {
            e = items.executeUserAttribute(task.items[i]);
            if (e.isError) {
                return exitWithCancelation(e);
            }
        } else if (task.items[i].type === "additionalAttribute") {
            e = items.executeAdditionalAttribute(task.items[i]);
            if (e.isError) {
                return exitWithCancelation(e);
            }
        } else if (task.items[i].type === "pixels") {
            var e = items.executePixelsBuffer(task.items[i]);
            if (e.isError) {
                return exitWithCancelation(e);
            }
        }
    }

    if (!validators.isMissing(task.total))
        total = task.total;

    Fptr.setParam(Fptr.LIBFPTR_PARAM_SUM, total);
    if (Fptr.receiptTotal() < 0)
        return exitWithCancelation(Fptr.error());

    if (!validators.isMissing(task.taxes)) {
        for (var i = 0; i < task.taxes.length; i++) {
            if (task.taxes[i].sum) {
                Fptr.setParam(Fptr.LIBFPTR_PARAM_TAX_TYPE, utils.parseTaxType(task.taxes[i].type));
                Fptr.setParam(Fptr.LIBFPTR_PARAM_TAX_SUM, task.taxes[i].sum);
                if (Fptr.receiptTax() < 0) {
                    return exitWithCancelation(Fptr.error());
                }
            }
        }
    }

    var paymentsSum = 0;
    for (var i = 0; i < task.payments.length; i++) {
        paymentsSum += Number(task.payments[i].sum.toFixed(2));
    }

    if (Number(paymentsSum.toFixed(2)) < Number(total.toFixed(2))) {
        return exitWithCancelation(Fptr.result(Fptr.LIBFPTR_ERROR_NOT_FULLY_PAID));
    }

    // Сначала записываем все неналичные оплаты, а потом отдельно наличные
    for (var i = 0; i < task.payments.length; i++) {
        var pt = utils.parsePaymentType(task.payments[i].type);
        var ps = task.payments[i].sum;
        if (pt !== Fptr.LIBFPTR_PT_CASH && ps !== 0) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_PAYMENT_TYPE, pt);
            Fptr.setParam(Fptr.LIBFPTR_PARAM_PAYMENT_SUM, ps);
            if (Fptr.payment() < 0) {
                return exitWithCancelation(Fptr.error());
            }

            if (!validators.isMissing(task.payments[i].printItems)) {
                for (var j = 0; j < task.payments[i].printItems.length; ++j) {
                    if (task.payments[i].printItems[j].type === "text") {
                        e = items.executeText(task.payments[i].printItems[j]);
                        if (e.isError && !task.ignoreNonFiscalPrintErrors) {
                            return exitWithCancelation(Fptr.error());
                        }
                    }
                }
            }
        }
    }

    for (var i = 0; i < task.payments.length; i++) {
        var pt = utils.parsePaymentType(task.payments[i].type);
        var ps = task.payments[i].sum;
        if (pt === Fptr.LIBFPTR_PT_CASH && ps !== 0) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_PAYMENT_TYPE, pt);
            Fptr.setParam(Fptr.LIBFPTR_PARAM_PAYMENT_SUM, ps);
            if (Fptr.payment() < 0) {
                return exitWithCancelation(Fptr.error());
            }

            if (!validators.isMissing(task.payments[i].printItems)) {
                for (var j = 0; j < task.payments[i].printItems.length; ++j) {
                    if (task.payments[i].printItems[j].type === "text") {
                        e = items.executeText(task.payments[i].printItems[j]);
                        if (e.isError && !task.ignoreNonFiscalPrintErrors) {
                            return exitWithCancelation(Fptr.error());
                        }
                    }
                }
            }
        }
    }

    if (Fptr.closeReceipt() < 0) {
        var e = Fptr.error();
        if (e.error === Fptr.LIBFPTR_ERROR_DENIED_IN_CLOSED_SHIFT) {
            return exitWithCancelation(e);
        }

        Fptr.checkDocumentClosed();
        if (!Fptr.getParamBool(Fptr.LIBFPTR_PARAM_DOCUMENT_CLOSED)) {
            return exitWithCancelation(e);
        }
    }

    return Fptr.ok(
        utils.getFiscalDocumentResult().result,
        {
            shiftAutoOpened: shiftAutoOpened
        });
};


function validateOldCorrection(task) {
    if (!validators.isMissing(validators.mustObjectOrMissing(task.operator, "operator"))) {
        validators.mustObject(task.operator, "operator");
        validators.mustString(task.operator.name, "operator.name");
        validators.mustStringOrMissing(task.operator.vatin, "operator.vatin");
    }

    validators.mustStringOrMissingValues(task.correctionType, "correctionType", ["self", "instruction"]);
    validators.mustStringOrMissing(task.correctionBaseName, "correctionBaseName");
    validators.mustStringOrMissing(task.correctionBaseNumber, "correctionBaseNumber");
    var dateString = validators.mustStringOrMissing(task.correctionBaseDate, "correctionBaseDate");
    if (!validators.isMissing(dateString)) {
        if (!reggie.test(dateString)) {
            throw new validators.InvalidJsonValueError("correctionBaseDate", dateString);
        }
    }

    validators.mustStringOrMissing(task.machineNumber, "machineNumber");
    validators.mustBooleanOrMissing(task.electronically, "electronically");
    validators.mustStringOrMissingValues(task.taxationType, "taxationType", Object.keys(utils.TAXATION_TYPES));

    var paymentsArray = validators.mustArray(task.payments, "payments");
    for (var i = 0; i < paymentsArray.length; ++i) {
        try {
            try {
                validators.mustStringValues(paymentsArray[i].type, "type", Object.keys(utils.PAYMENT_TYPES));
            } catch (e) {
                if (e.name === "InvalidJsonValueError") {
                    if (isNaN(parseInt(paymentsArray[i].type, 10)))
                        throw e;
                } else {
                    throw e;
                }
            }
            validators.mustNumber(paymentsArray[i].sum, "sum");

            var printItems = validators.mustArrayOrMissing(paymentsArray[i].printItems, "printItems");
            if (!validators.isMissing(printItems)) {
                for (var i = 0; i < printItems.length; ++i) {
                    try {
                        var type = validators.mustString(printItems[i].type, "type");
                        if (type === "text") {
                            validators.validateTextItem(printItems[i]);
                        } else if (type === "barcode") {
                            validators.validateBarcodeItem(printItems[i]);
                        } else if (type === "pictureFromMemory") {
                            validators.validatePictureFromMemoryItem(printItems[i]);
                        } else if (type === "pixels") {
                            validators.validatePixelsItem(printItems[i]);
                        }
                    } catch (e) {
                        if (e.name === "InvalidJsonValueError") {
                            throw new validators.InvalidJsonValueError(utils.makeDotPath("printItems[" + i + "]", e.path), e.value);
                        } else if (e.name === "InvalidJsonTypeError") {
                            throw new validators.InvalidJsonTypeError(utils.makeDotPath("printItems[" + i + "]", e.path), e.expectedType);
                        } else if (e.name === "JsonValueNotFoundError") {
                            throw new validators.JsonValueNotFoundError(utils.makeDotPath("printItems[" + i + "]", e.path));
                        } else {
                            throw e;
                        }
                    }
                }
            }

        } catch (e) {
            if (e.name === "InvalidJsonValueError") {
                throw new validators.InvalidJsonValueError(utils.makeDotPath("payments[" + i + "]", e.path), e.value);
            } else if (e.name === "InvalidJsonTypeError") {
                throw new validators.InvalidJsonTypeError(utils.makeDotPath("payments[" + i + "]", e.path), e.expectedType);
            } else if (e.name === "JsonValueNotFoundError") {
                throw new validators.JsonValueNotFoundError(utils.makeDotPath("payments[" + i + "]", e.path));
            } else {
                throw e;
            }
        }
    }

    var taxesArray = validators.mustArrayOrMissing(task.taxes, "taxes");
    if (!validators.isMissing(taxesArray)) {
        for (var i = 0; i < taxesArray.length; ++i) {
            try {
                validators.mustStringValues(taxesArray[i].type, "type", Object.keys(utils.TAX_TYPES));
                validators.mustNumber(taxesArray[i].sum, "sum");
            } catch (e) {
                if (e.name === "InvalidJsonValueError") {
                    throw new validators.InvalidJsonValueError(utils.makeDotPath("taxes[" + i + "]", e.path), e.value);
                } else if (e.name === "InvalidJsonTypeError") {
                    throw new validators.InvalidJsonTypeError(utils.makeDotPath("taxes[" + i + "]", e.path), e.expectedType);
                } else if (e.name === "JsonValueNotFoundError") {
                    throw new validators.JsonValueNotFoundError(utils.makeDotPath("taxes[" + i + "]", e.path));
                } else {
                    throw e;
                }
            }
        }
    }

    if (!validators.isMissing(validators.mustArrayOrMissing(task.preItems, "preItems"))) {
        validators.validatePreItems(task.preItems);
    }
    if (!validators.isMissing(validators.mustArrayOrMissing(task.postItems, "postItems"))) {
        validators.validatePostItems(task.postItems);
    }
}

exports.executeOldCorrection = function (task) {
    try {
        validateOldCorrection(task);
    } catch (e) {
        if (e.name === "InvalidJsonValueError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Некорректное значение поля \"" + e.path + "\" (" + e.value + ")")
        } else if (e.name === "InvalidJsonTypeError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Поле \"" + e.path + "\" имеет неверный тип (ожидается \"" + e.expectedType + "\")");
        } else if (e.name === "JsonValueNotFoundError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Поле \"" + e.path + "\" отсутствует");
        } else {
            throw e;
        }
    }

    if (Fptr.cancelReceipt() < 0 && !utils.isNormalCancelError(Fptr.errorCode())) {
        return Fptr.error();
    }

    if (!validators.isMissing(task.operator) && task.operator.name) {
        Fptr.setParam(1021, task.operator.name);
        Fptr.setParam(1203, task.operator.vatin, Fptr.IGNORE_IF_EMPTY);
        if (Fptr.operatorLogin() < 0) {
            return Fptr.error();
        }
    }

    if (!task.electronically) {
        if (!validators.isMissing(task.preItems)) {
            items.executePreItems(task.preItems);
        }
        if (!validators.isMissing(task.postItems)) {
            items.executePostItems(task.postItems);
        }
    }

    var correctionType = undefined;
    switch (task.correctionType) {
        case "self":
            correctionType = 0;
            break;
        case "instruction":
            correctionType = 1;
            break;
    }

    var dateString = task.correctionBaseDate;
    if (!validators.isMissing(dateString)) {
        var dateArray = reggie.exec(dateString);
        var dateObject = new Date();
        dateObject.setUTCFullYear(+dateArray[1]);
        dateObject.setUTCMonth(+dateArray[2] - 1, +dateArray[3]);
        dateObject.setUTCHours(0, 0, 0, 0);
    }

    Fptr.setParam(1177, task.correctionBaseName, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1178, dateObject, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1179, task.correctionBaseNumber, Fptr.IGNORE_IF_EMPTY);
    Fptr.utilFormTlv();
    var tag1174 = Fptr.getParamByteArray(Fptr.LIBFPTR_PARAM_TAG_VALUE);

    Fptr.setParam(Fptr.LIBFPTR_PARAM_RECEIPT_TYPE, utils.CORRECTION_TYPES[task.type], Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1036, task.machineNumber, Fptr.IGNORE_IF_EMPTY);

    Fptr.setParam(Fptr.LIBFPTR_PARAM_USE_VAT18, task.useVAT18, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_RECEIPT_ELECTRONICALLY, task.electronically, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1055, utils.TAXATION_TYPES[task.taxationType], Fptr.IGNORE_IF_EMPTY);

    Fptr.setParam(1173, correctionType, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1174, tag1174, Fptr.IGNORE_IF_EMPTY);

    var res = Fptr.openReceipt();
    var shiftAutoOpened = Fptr.getParamBool(Fptr.LIBFPTR_PARAM_SHIFT_AUTO_OPENED);
    if (res < 0) {
        return exitWithCancelation(Fptr.error());
    }

    var paymentsSum = 0;
    for (var i = 0; i < task.payments.length; i++) {
        paymentsSum += task.payments[i].sum;
    }

    Fptr.setParam(Fptr.LIBFPTR_PARAM_SUM, paymentsSum);
    if (Fptr.receiptTotal() < 0)
        return exitWithCancelation(Fptr.error());

    if (!validators.isMissing(task.taxes)) {
        for (var i = 0; i < task.taxes.length; i++) {
            if (task.taxes[i].sum) {
                Fptr.setParam(Fptr.LIBFPTR_PARAM_TAX_TYPE, utils.parseTaxType(task.taxes[i].type));
                Fptr.setParam(Fptr.LIBFPTR_PARAM_TAX_SUM, task.taxes[i].sum);
                if (Fptr.receiptTax() < 0) {
                    return exitWithCancelation(Fptr.error());
                }
            }
        }
    }

    // Сначала записываем все неналичные оплаты, а потом отдельно наличные
    for (var i = 0; i < task.payments.length; i++) {
        var pt = utils.parsePaymentType(task.payments[i].type);
        var ps = task.payments[i].sum;
        if (pt !== Fptr.LIBFPTR_PT_CASH && ps !== 0) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_PAYMENT_TYPE, pt);
            Fptr.setParam(Fptr.LIBFPTR_PARAM_PAYMENT_SUM, ps);
            if (Fptr.payment() < 0) {
                return exitWithCancelation(Fptr.error());
            }

            if (!validators.isMissing(task.payments[i].printItems)) {
                for (var j = 0; j < task.payments[i].printItems.length; ++j) {
                    if (task.payments[i].printItems.type === "text") {
                        e = items.executeText(task.payments[i].printItems[i]);
                        if (e.isError && !task.ignoreNonFiscalPrintErrors) {
                            return exitWithCancelation(Fptr.error());
                        }
                    }
                }
            }
        }
    }

    for (var i = 0; i < task.payments.length; i++) {
        var pt = utils.parsePaymentType(task.payments[i].type);
        var ps = task.payments[i].sum;
        if (pt === Fptr.LIBFPTR_PT_CASH && ps !== 0) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_PAYMENT_TYPE, pt);
            Fptr.setParam(Fptr.LIBFPTR_PARAM_PAYMENT_SUM, ps);
            if (Fptr.payment() < 0) {
                return exitWithCancelation(Fptr.error());
            }

            if (!validators.isMissing(task.payments[i].printItems)) {
                for (var j = 0; j < task.payments[i].printItems.length; ++j) {
                    if (task.payments[i].printItems.type === "text") {
                        e = items.executeText(task.payments[i].printItems[i]);
                        if (e.isError && !task.ignoreNonFiscalPrintErrors) {
                            return exitWithCancelation(Fptr.error());
                        }
                    }
                }
            }
        }
    }

    if (Fptr.closeReceipt() < 0) {
        var e = Fptr.error();
        if (e.error === Fptr.LIBFPTR_ERROR_DENIED_IN_CLOSED_SHIFT) {
            return exitWithCancelation(e);
        }

        Fptr.checkDocumentClosed();
        if (!Fptr.getParamBool(Fptr.LIBFPTR_PARAM_DOCUMENT_CLOSED)) {
            return exitWithCancelation(e);
        }
    }

    return Fptr.ok(
        utils.getFiscalDocumentResult().result,
        {
            shiftAutoOpened: shiftAutoOpened
        });
};

exports.validateNewCorrection = function(task) {
    try {
        validateNewCorrection(task);
    } catch (e) {
        if (e.name === "InvalidJsonValueError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Некорректное значение поля \"" + e.path + "\" (" + e.value + ")")
        } else if (e.name === "InvalidJsonTypeError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Поле \"" + e.path + "\" имеет неверный тип (ожидается \"" + e.expectedType + "\")");
        } else if (e.name === "JsonValueNotFoundError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Поле \"" + e.path + "\" отсутствует");
        } else {
            throw e;
        }
    }
    return Fptr.ok();
};

exports.validateOldCorrection = function(task) {
    try {
        validateOldCorrection(task);
    } catch (e) {
        if (e.name === "InvalidJsonValueError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Некорректное значение поля \"" + e.path + "\" (" + e.value + ")")
        } else if (e.name === "InvalidJsonTypeError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Поле \"" + e.path + "\" имеет неверный тип (ожидается \"" + e.expectedType + "\")");
        } else if (e.name === "JsonValueNotFoundError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Поле \"" + e.path + "\" отсутствует");
        } else {
            throw e;
        }
    }
    return Fptr.ok();
};

