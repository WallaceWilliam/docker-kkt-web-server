const utils = require('myscripts_utils');
const validators = require('myscripts_validators');

function setAlignment(alignment, defaultAlignment) {
    if (validators.isMissing(alignment)) {
        Fptr.setParam(Fptr.LIBFPTR_PARAM_ALIGNMENT, defaultAlignment);
        return;
    }

    switch (alignment) {
        case "left":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_ALIGNMENT, Fptr.LIBFPTR_ALIGNMENT_LEFT);
            break;
        case "center":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_ALIGNMENT, Fptr.LIBFPTR_ALIGNMENT_CENTER);
            break;
        case "right":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_ALIGNMENT, Fptr.LIBFPTR_ALIGNMENT_RIGHT);
            break;
    }
}

exports.executeText = function (text, defer) {
    if (!validators.isMissing(defer)) {
        if (defer !== Fptr.LIBFPTR_DEFER_NONE) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_DEFER, defer)
        }
    }

    Fptr.setParam(Fptr.LIBFPTR_PARAM_TEXT, text.text, Fptr.IGNORE_IF_EMPTY);
    setAlignment(text.alignment, Fptr.LIBFPTR_ALIGNMENT_LEFT);

    switch (text.wrap) {
        case "none":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_TEXT_WRAP, Fptr.LIBFPTR_TW_NONE);
            break;
        case "chars":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_TEXT_WRAP, Fptr.LIBFPTR_TW_CHARS);
            break;
        case "words":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_TEXT_WRAP, Fptr.LIBFPTR_TW_WORDS);
            break;
    }

    Fptr.setParam(Fptr.LIBFPTR_PARAM_FONT, text.font, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_FONT_DOUBLE_WIDTH, text.doubleWidth, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_FONT_DOUBLE_HEIGHT, text.doubleHeight, Fptr.IGNORE_IF_EMPTY);
    Fptr.printText();
    return Fptr.error();
};

exports.executeBarcode = function (barcode, defer) {
    var overlay = barcode.overlay;

    if (!validators.isMissing(overlay)) {
        for (var i = 0; i < overlay.length; i++) {
            var e = this.executeText(overlay[i], Fptr.LIBFPTR_DEFER_OVERLAY);
            if (e.isError) {
                return e;
            }
        }
    }

    if (!validators.isMissing(defer) && defer !== Fptr.LIBFPTR_DEFER_NONE) {
        Fptr.setParam(Fptr.LIBFPTR_PARAM_DEFER, defer)
    }

    Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE, barcode.barcode);
    switch (barcode.barcodeType) {
        case "EAN8":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_EAN_8);
            break;
        case "EAN13":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_EAN_13);
            break;
        case "UPCA":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_UPC_A);
            break;
        case "UPCE":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_UPC_E);
            break;
        case "CODE39":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_CODE_39);
            break;
        case "CODE93":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_CODE_93);
            break;
        case "CODE128":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_CODE_128);
            break;
        case "CODABAR":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_CODABAR);
            break;
        case "ITF":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_ITF);
            break;
        case "ITF14":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_ITF_14);
            break;
        case "GS1_128":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_GS1_128);
            break;
        case "PDF417":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_PDF417);
            break;
        case "QR":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_QR);
            break;
        case "CODE39_EXTENDED":
            Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_TYPE, Fptr.LIBFPTR_BT_CODE_39_EXTENDED);
            break;
    }

    setAlignment(barcode.alignment, Fptr.LIBFPTR_ALIGNMENT_CENTER);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_SCALE, barcode.scale, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_HEIGHT, barcode.height, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_BARCODE_PRINT_TEXT, barcode.printText, Fptr.IGNORE_IF_EMPTY);
    Fptr.printBarcode();
    return Fptr.error();
};

exports.executePictureFromMemory = function (picture, defer) {
    Fptr.setParam(Fptr.LIBFPTR_PARAM_PICTURE_NUMBER, picture.pictureNumber);
    setAlignment(picture.alignment, Fptr.LIBFPTR_ALIGNMENT_CENTER);

    if (!validators.isMissing(defer) && defer !== Fptr.LIBFPTR_DEFER_NONE) {
        Fptr.setParam(Fptr.LIBFPTR_PARAM_DEFER, defer)
    }

    Fptr.printPictureByNumber();
    return Fptr.error();
};

exports.executePixelsBuffer = function (pixelBuffer, defer) {
    Fptr.setParam(Fptr.LIBFPTR_PARAM_PIXEL_BUFFER, Duktape.dec("base64", pixelBuffer.pixels));
    Fptr.setParam(Fptr.LIBFPTR_PARAM_WIDTH, pixelBuffer.width);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_SCALE_PERCENT, pixelBuffer.scale, Fptr.IGNORE_IF_EMPTY);
    setAlignment(pixelBuffer.alignment, Fptr.LIBFPTR_ALIGNMENT_CENTER);

    if (!validators.isMissing(defer) && defer !== Fptr.LIBFPTR_DEFER_NONE) {
        Fptr.setParam(Fptr.LIBFPTR_PARAM_DEFER, defer)
    }

    Fptr.printPixelBuffer();
    return Fptr.error();
};

exports.executeUserAttribute = function (userAttribute) {
    Fptr.setParam(1085, userAttribute.name);
    Fptr.setParam(1086, userAttribute.value);
    Fptr.utilFormTlv();
    var tag1084 = Fptr.getParamByteArray(Fptr.LIBFPTR_PARAM_TAG_VALUE);

    if (validators.isMissing(userAttribute.print) || userAttribute.print) {
        Fptr.setParam(1084, tag1084);
    } else {
        Fptr.setNonPrintableParam(1084, tag1084);
    }

    Fptr.fnWriteAttributes();
    return Fptr.error();
};

exports.executeAdditionalAttribute = function (additionalAttribute) {
    if (validators.isMissing(additionalAttribute.print) || additionalAttribute.print) {
        Fptr.setParam(1192, additionalAttribute.value);
    } else {
        Fptr.setNonPrintableParam(1192, additionalAttribute.value);
    }

    Fptr.fnWriteAttributes();
    return Fptr.error();
};

exports.executePosition = function (position) {
    if (!validators.isMissing(position.agentInfo)) {
        if (!validators.isMissing(position.agentInfo.moneyTransferOperator)) {
            Fptr.setParam(1005, position.agentInfo.moneyTransferOperator.address, Fptr.IGNORE_IF_EMPTY);
            Fptr.setParam(1016, position.agentInfo.moneyTransferOperator.vatin, Fptr.IGNORE_IF_EMPTY);
            Fptr.setParam(1026, position.agentInfo.moneyTransferOperator.name, Fptr.IGNORE_IF_EMPTY);
            phones = position.agentInfo.moneyTransferOperator.phones;
            for (var i = 0; phones && i < phones.length; i++) {
                Fptr.setParam(1075, phones[i], Fptr.IGNORE_IF_EMPTY);
            }
        }
        if (!validators.isMissing(position.agentInfo.payingAgent)) {
            Fptr.setParam(1044, position.agentInfo.payingAgent.operation, Fptr.IGNORE_IF_EMPTY);
            phones = position.agentInfo.payingAgent.phones;
            for (var i = 0; phones && i < phones.length; i++) {
                Fptr.setParam(1073, phones[i], Fptr.IGNORE_IF_EMPTY);
            }
        }

        if (!validators.isMissing(position.agentInfo.receivePaymentsOperator)) {
            phones = position.agentInfo.receivePaymentsOperator.phones;
            for (var i = 0; phones && i < phones.length; i++) {
                Fptr.setParam(1074, phones[i], Fptr.IGNORE_IF_EMPTY);
            }
        }

        Fptr.utilFormTlv();
        var tag1223 = Fptr.getParamByteArray(Fptr.LIBFPTR_PARAM_TAG_VALUE);
    }

    if (!validators.isMissing(position.supplierInfo)) {
        Fptr.setParam(1225, position.supplierInfo.name, Fptr.IGNORE_IF_EMPTY);
        phones = position.supplierInfo.phones;
        for (var i = 0; phones && i < phones.length; i++) {
            Fptr.setParam(1171, phones[i], Fptr.IGNORE_IF_EMPTY);
        }

        Fptr.utilFormTlv();
        var tag1224 = Fptr.getParamByteArray(Fptr.LIBFPTR_PARAM_TAG_VALUE);
    }

    if (!validators.isMissing(position.markingCode)) {
        Fptr.setParam(Fptr.LIBFPTR_PARAM_MARKING_CODE, Duktape.dec("base64", position.markingCode.mark));
        Fptr.setParam(Fptr.LIBFPTR_PARAM_MARKING_CODE_TYPE, utils.MARKING_CODE_TYPES[position.markingCode.type], Fptr.IGNORE_IF_EMPTY);
    } else if (!validators.isMissing(position.nomenclatureCode)) {
        if (typeof position.nomenclatureCode === "string") {
            Fptr.setParam(1162, Duktape.dec("base64", position.nomenclatureCode));
        } else if (typeof position.nomenclatureCode === "object" && !validators.isMissing(position.nomenclatureCode)) {
            switch (position.nomenclatureCode.type) {
                case "furs":
                    Fptr.setParam(Fptr.LIBFPTR_PARAM_NOMENCLATURE_TYPE, Fptr.LIBFPTR_NT_FURS);
                    break;
                case "medicines":
                    Fptr.setParam(Fptr.LIBFPTR_PARAM_NOMENCLATURE_TYPE, Fptr.LIBFPTR_NT_MEDICINES);
                    break;
                case "tobacco":
                    Fptr.setParam(Fptr.LIBFPTR_PARAM_NOMENCLATURE_TYPE, Fptr.LIBFPTR_NT_TOBACCO);
                    break;
                case "shoes":
                    Fptr.setParam(Fptr.LIBFPTR_PARAM_NOMENCLATURE_TYPE, Fptr.LIBFPTR_NT_SHOES);
                    break;
            }
            Fptr.setParam(Fptr.LIBFPTR_PARAM_GTIN, position.nomenclatureCode.gtin, Fptr.IGNORE_IF_EMPTY);
            Fptr.setParam(Fptr.LIBFPTR_PARAM_SERIAL_NUMBER, position.nomenclatureCode.serial);
            if (Fptr.utilFormNomenclature() < 0) {
                return Fptr.error();
            }

            Fptr.setParam(1162, Fptr.getParamByteArray(Fptr.LIBFPTR_PARAM_TAG_VALUE));
        }
    }

    if (!validators.isMissing(position.agentInfo)) {
        if (!validators.isMissing(position.agentInfo.agents)) {
            var agentType = Fptr.LIBFPTR_AT_NONE;
            for (var i = 0; i < position.agentInfo.agents.length; i++) {
                agentType |= utils.AGENT_TYPES[position.agentInfo.agents[i]];
            }
            if (agentType > 0) {
                Fptr.setParam(1222, agentType);
            }
        }
    }
    if (!validators.isMissing(position.supplierInfo)) {
        Fptr.setParam(1226, position.supplierInfo.vatin, Fptr.IGNORE_IF_EMPTY);
    }
    Fptr.setParam(1223, tag1223, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1224, tag1224, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1197, position.measurementUnit, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1229, position.exciseSum, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1230, position.countryCode, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1231, position.customsDeclaration, Fptr.IGNORE_IF_EMPTY);
    Fptr.setUserParam(3, position.ucUserParam3, Fptr.IGNORE_IF_EMPTY);
    Fptr.setUserParam(4, position.ucUserParam4, Fptr.IGNORE_IF_EMPTY);
    Fptr.setUserParam(5, position.ucUserParam5, Fptr.IGNORE_IF_EMPTY);
    Fptr.setUserParam(6, position.ucUserParam6, Fptr.IGNORE_IF_EMPTY);

    if (!validators.isMissing(position.additionalAttribute)) {
        if (validators.isMissing(position.additionalAttributePrint) || position.additionalAttributePrint) {
            Fptr.setParam(1191, position.additionalAttribute);
        }
        else {
            Fptr.setNonPrintableParam(1191, position.additionalAttribute);
        }
    }

    Fptr.setParam(Fptr.LIBFPTR_PARAM_COMMODITY_NAME, position.name);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_PRICE, position.price);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_QUANTITY, position.quantity);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_POSITION_SUM, position.amount);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_INFO_DISCOUNT_SUM, position.infoDiscountAmount, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_DEPARTMENT, position.department, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_TAX_TYPE, utils.parseTaxType(position.tax.type));
    Fptr.setParam(Fptr.LIBFPTR_PARAM_USE_ONLY_TAX_TYPE, validators.isMissing(position.tax.sum));
    if (!validators.isMissing(position.tax.sum)) {
        Fptr.setParam(Fptr.LIBFPTR_PARAM_TAX_SUM, position.tax.sum);
    }
    Fptr.setParam(Fptr.LIBFPTR_PARAM_COMMODITY_PIECE, position.piece, Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1214, utils.parsePaymentMethod(position.paymentMethod), Fptr.IGNORE_IF_EMPTY);
    Fptr.setParam(1212, utils.parsePaymentObject(position.paymentObject), Fptr.IGNORE_IF_EMPTY);

    Fptr.registration();
    return Fptr.error();
};

exports.executePreItems = function (preItems) {
    for (var i = 0; i < preItems.length; i++) {
        if (preItems[i].type === "text") {
            var e = this.executeText(preItems[i], Fptr.LIBFPTR_DEFER_PRE);
            if (e.isError) {
                return e;
            }
        } else if (preItems[i].type === "barcode") {
            var e = this.executeBarcode(preItems[i], Fptr.LIBFPTR_DEFER_PRE);
            if (e.isError) {
                return e;
            }
        } else if (preItems[i].type === "pictureFromMemory") {
            var e = this.executePictureFromMemory(preItems[i], Fptr.LIBFPTR_DEFER_PRE);
            if (e.isError) {
                return e;
            }
        } else if (preItems[i].type === "pixels") {
            e = this.executePixelsBuffer(preItems[i], Fptr.LIBFPTR_DEFER_PRE);
            if (e.isError) {
                return e;
            }
        }
    }

    return Fptr.ok();
};

exports.executePostItems = function (postItems) {
    Fptr.readModelFlags();
    if (Fptr.getParamBool(Fptr.LIBFPTR_PARAM_CAP_MANUAL_CLICHE_CONTROL)) {
        if (postItems.length > 0) {
            for (var i = 0; i < postItems.length; i++) {
                if (postItems[i].type === "text") {
                    var e = this.executeText(postItems[i], Fptr.LIBFPTR_DEFER_POST);
                    if (e.isError) {
                        return e;
                    }
                } else if (postItems[i].type === "barcode") {
                    var e = this.executeBarcode(postItems[i], Fptr.LIBFPTR_DEFER_POST);
                    if (e.isError) {
                        return e;
                    }
                } else if (postItems[i].type === "pictureFromMemory") {
                    var e = this.executePictureFromMemory(postItems[i], Fptr.LIBFPTR_DEFER_POST);
                    if (e.isError) {
                        return e;
                    }
                } else if (postItems[i].type === "pixels") {
                    e = this.executePixelsBuffer(postItems[i], Fptr.LIBFPTR_DEFER_POST);
                    if (e.isError) {
                        return e;
                    }
                }
            }

            Fptr.disableAutoCliche();
        } else {
            Fptr.enableAutoCliche();
        }
    }

    return Fptr.ok();
};
