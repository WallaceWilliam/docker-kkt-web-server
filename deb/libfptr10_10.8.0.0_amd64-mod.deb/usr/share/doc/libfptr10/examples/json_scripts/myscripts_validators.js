const utils = require('myscripts_utils');

/**
 * Проверяет наличие значения у поля
 * @param field Поле
 * @returns {boolean} true, если поле имеет значение
 */
exports.isMissing = function (field) {
    if ((field === null) || (field === undefined)) {
        return true;
    }
    if (typeof(field) === "object") {
        return (Object.keys(field).length === 0 && field.constructor === Object);
    }

    return false;
};

/**
 * Проверяет, задано ли значение поля
 * @param field Поле
 * @param name Наименование поля для исключения
 * @returns Значение поля
 * @throws JsonValueNotFoundError, если поле не найдено
 */
exports.mustValue = function(field, name) {
    if (exports.isMissing(field)) {
        throw new exports.JsonValueNotFoundError(name);
    }
    return field;
};
/**
 * Проверяет, что тип поля соответствует одному из указанных
 * @param field Поле
 * @param name Наименование поля для исключения
 * @param types Список типов
 * @returns Значение поля
 * @throws JsonValueNotFoundError, если поле не найдено
 * @throws InvalidJsonTypeError, если тип поля не входит список types
 */
exports.mustTypes = function(field, name, types) {
    exports.mustValue(field, name);
    if (types.indexOf(typeof(field)) < 0) {
        throw new exports.InvalidJsonTypeError(name, types.join("|"));
    }
    return field;
};
/**
 * Проверяет, что тип поля соответствует одному из указанных или отсутствует
 * @param field Поле
 * @param name Наименование поля для исключения
 * @param types Список типов
 * @returns Значение поля
 * @throws InvalidJsonTypeError, если тип поля не входит список types
 */
exports.mustTypesOrMissing = function(field, name, types) {
    types.push("undefined");
    if (field !== null && types.indexOf(typeof(field)) < 0) {
        throw new exports.InvalidJsonTypeError(name, types.join("|"));
    }
    return field;
};

/**
 * Проверяет, что поле - числовое
 * @param field Поле
 * @param name Наименование поля для исключения
 * @returns Значение поля
 * @throws JsonValueNotFoundError, если поле не найдено
 * @throws InvalidJsonTypeError, если значение поля - не число
 */
exports.mustNumber = function(field, name) {
    exports.mustTypes(field, name, ["number"]);
    return field
};
/**
 * Проверяет, что поле - логическое
 * @param field Поле
 * @param name Наименование поля для исключения
 * @returns Значение поля
 * @throws JsonValueNotFoundError, если поле не найдено
 * @throws InvalidJsonTypeError, если значение поля - не bool
 */
exports.mustBoolean = function(field, name) {
    exports.mustTypes(field, name, ["boolean"]);
    return field
};
/**
 * Проверяет, что поле - строковое
 * @param field Поле
 * @param name Наименование поля для исключения
 * @returns Значение поля
 * @throws JsonValueNotFoundError, если поле не найдено
 * @throws InvalidJsonTypeError, если значение поля - не строка
 */
exports.mustString = function(field, name) {
    exports.mustTypes(field, name, ["string"]);
    return field
};
/**
 * Проверяет, что поле - произвольный объект
 * @param field Поле
 * @param name Наименование поля для исключения
 * @returns Значение поля
 * @throws JsonValueNotFoundError, если поле не найдено
 * @throws InvalidJsonTypeError, если значение поля - не объект
 */
exports.mustObject = function(field, name) {
    exports.mustTypes(field, name, ["object"]);
    return field
};
/**
 * Проверяет, что поле - массив
 * @param field Поле
 * @param name Наименование поля для исключения
 * @return Поле
 * @throws JsonValueNotFoundError, если поле не найдено
 * @throws InvalidJsonTypeError, если значение поля - не массив
 */
exports.mustArray = function(field, name) {
    exports.mustValue(field, name);
    if (Object.prototype.toString.call(field) !== "[object Array]") {
        throw new exports.InvalidJsonTypeError(name, "array");
    }
    return field
};
/**
 * Проверяет, что поле - массив байтов
 * @param field Поле
 * @param name Наименование поля для исключения
 * @return Поле
 * @throws JsonValueNotFoundError, если поле не найдено
 * @throws InvalidJsonTypeError, если значение поля - не массив байтов
 */
exports.mustByteArray = function(field, name) {
    exports.mustValue(field, name);
    if (Object.prototype.toString.call(field) !== "[object Uint8Array]") {
        throw new exports.InvalidJsonTypeError(name, "array");
    }
    return field
};

/**
 * Проверяет, что поле - числовое или отсутствует
 * @param field Поле
 * @param name Наименование поля для исключения
 * @returns Значение поля
 * @throws InvalidJsonTypeError, если значение поля - не число
 */
exports.mustNumberOrMissing = function(field, name) {
    exports.mustTypesOrMissing(field, name, ["number"]);
    return field
};
/**
 * Проверяет, что поле - логическое или отсутствует
 * @param field Поле
 * @param name Наименование поля для исключения
 * @returns Значение поля
 * @throws InvalidJsonTypeError, если значение поля - не bool
 */
exports.mustBooleanOrMissing = function(field, name) {
    exports.mustTypesOrMissing(field, name, ["boolean"]);
    return field
};
/**
 * Проверяет, что поле - строковое или отсутствует
 * @param field Поле
 * @param name Наименование поля для исключения
 * @returns Значение поля
 * @throws InvalidJsonTypeError, если значение поля - не строка
 */
exports.mustStringOrMissing = function(field, name) {
    exports.mustTypesOrMissing(field, name, ["string"]);
    return field
};
/**
 * Проверяет, что поле - произвольный объект или отсутствует
 * @param field Поле
 * @param name Наименование поля для исключения
 * @return Поле
 * @throws InvalidJsonTypeError, если значение поля - не объект
 */
exports.mustObjectOrMissing = function(field, name) {
    exports.mustTypesOrMissing(field, name, ["object"]);
    return field
};
/**
 * Проверяет, что поле - массив или отсутствует
 * @param field Поле
 * @param name Наименование поля для исключения
 * @returns Значение поля
 * @throws InvalidJsonTypeError, если значение поля - не массив
 */
exports.mustArrayOrMissing = function(field, name) {
    if (!exports.isMissing(field) && Object.prototype.toString.call(field) !== "[object Array]") {
        throw new exports.InvalidJsonTypeError(name, "array|undefined");
    }
    return field
};

/**
 * Проверяет, что поле - строковое, и его значение соответствует одному из списка
 * @param field Поле
 * @param name Наименование поля для исключения
 * @param values Список возможных значений
 * @returns Значение поля
 * @throws JsonValueNotFoundError, если поле не найдено
 * @throws InvalidJsonTypeError, если значение поля - не строка
 * @throws InvalidJsonValueError, если значение поля не соответствуюет ни одному из values
 */
exports.mustStringValues = function(field, name, values) {
    exports.mustTypes(field, name, ["string"]);
    if (values.indexOf(field) < 0) {
        throw new exports.InvalidJsonValueError(name, field);
    }
    return field
};

/**
 * Проверяет, что поле - строковое и его значение соответствует одному из списка, либо отсутствует
 * @param field Поле
 * @param name Наименование поля для исключения
 * @param values Список возможных значений
 * @returns Значение поля
 * @throws InvalidJsonTypeError, если значение поля - не строка
 * @throws InvalidJsonValueError, если значение поля не соответствуюет ни одному из values
 */
exports.mustStringOrMissingValues = function(field, name, values) {
    exports.mustTypesOrMissing(field, name, ["string"]);
    if (!exports.isMissing(field) && field && values.indexOf(field) < 0) {
        throw new exports.InvalidJsonValueError(name, field);
    }
    return field
};

/**
 * Проверяет, что поле - произвольный объект, и проверяет его значение через переданный валидатор
 * @param field Поле
 * @param name Наименование поля для исключения
 * @param validator Валидатор
 * @returns Значение поля
 * @throws JsonValueNotFoundError, если поле не найдено
 * @throws InvalidJsonTypeError, если значение поля - не объект
 * @throws Исключения, которые возвращает переданный валидатор
 */
exports.mustObjectValidator = function(field, name, validator) {
    exports.mustObject(field, name);
    validator(field);
    return field
};

/**
 * Проверяет, что поле - произвольный объект, и проверяет его значение через переданный валидатор; либо поле отсутствует
 * @param field Поле
 * @param name Наименование поля для исключения
 * @param validator Валидатор
 * @returns Значение поля
 * @throws InvalidJsonTypeError, если значение поля - не объект
 * @throws Исключения, которые возвращает переданный валидатор
 */
exports.mustObjectOrMissingValidator = function(field, name, validator) {
    exports.mustObjectOrMissing(field, name);
    if (!exports.isMissing(field))
        validator(field);
    return field
};

/**
 * Исключение - некорректное значение поля в JSON-задании
 * @param path Путь к полю
 * @param value Текущее значение поля
 * @constructor
 */
exports.InvalidJsonValueError = function (path, value) {
    this.name = "InvalidJsonValueError";
    this.path = path;
    this.value = value;
};

/**
 * Исключение - некорректный тип поля в JSON-задании
 * @param path Путь к полю
 * @param expectedType Ожидаемый тип
 * @constructor
 */
exports.InvalidJsonTypeError = function (path, expectedType) {
    this.name = "InvalidJsonTypeError";
    this.path = path;
    this.expectedType = expectedType;
};

/**
 * Исключение - поле не найдено
 * @param path Путь к полю
 * @constructor
 */
exports.JsonValueNotFoundError = function (path) {
    this.name = "JsonValueNotFoundError";
    this.path = path;
};

/**
 * Проверяет элемент документа (чека) "Текст"
 * @param item Текстовое поле
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validateTextItem = function(item) {
    exports.mustStringOrMissing(item.text, "text");
    exports.mustStringOrMissingValues(item.alignment, "alignment", ["left", "center", "right"]);
    exports.mustStringOrMissingValues(item.wrap, "wrap", ["none", "chars", "words"]);
    exports.mustNumberOrMissing(item.font, "font");
    exports.mustBooleanOrMissing(item.doubleWidth, "doubleWidth");
    exports.mustBooleanOrMissing(item.doubleHeight, "doubleHeight");
};

/**
 * Проверяет элемент документа (чека) "Штрихкод"
 * @param item Штрихкод
 * @throws JsonValueNotFoundError, если одно из обязательных полей не найдено
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validateBarcodeItem = function(item) {
    exports.mustString(item.barcode, "barcode");
    exports.mustStringValues(item.barcodeType, "barcodeType", [
        "EAN8", "EAN13", "UPCA", "UPCE", "CODE39", "CODE93", "CODE128",
        "CODABAR", "ITF", "ITF14", "GS1_128", "PDF417", "QR", "CODE39_EXTENDED"]);
    exports.mustStringOrMissingValues(item.alignment, "alignment", ["left", "center", "right"]);
    exports.mustNumberOrMissing(item.scale, "scale");
    exports.mustNumberOrMissing(item.height, "height");
    exports.mustBooleanOrMissing(item.printText, "printText");
    var overlay = exports.mustArrayOrMissing(item.overlay, "overlay");
    if (!exports.isMissing(overlay)) {
        for (var i = 0; i < overlay.length; ++i) {
            try {
                var type = exports.mustString(overlay[i].type, "type");
                if (type === "text") {
                    exports.validateTextItem(overlay[i]);
                }
            } catch (e) {
                if (e.name === "InvalidJsonValueError") {
                    throw new exports.InvalidJsonValueError(utils.makeDotPath("overlay[" + i + "]", e.path), e.value);
                } else if (e.name === "InvalidJsonTypeError") {
                    throw new exports.InvalidJsonTypeError(utils.makeDotPath("overlay[" + i + "]", e.path), e.expectedType);
                } else if (e.name === "JsonValueNotFoundError") {
                    throw new exports.JsonValueNotFoundError(utils.makeDotPath("overlay[" + i + "]", e.path));
                } else {
                    throw e;
                }
            }
        }
    }
};

/**
 * Проверяет элемент документа (чека) "Картинка из памяти"
 * @param item Картинка из памяти
 * @throws JsonValueNotFoundError, если одно из обязательных полей не найдено
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validatePictureFromMemoryItem = function(item) {
    exports.mustNumber(item.pictureNumber, "pictureNumber");
    exports.mustStringOrMissingValues(item.alignment, "alignment", ["left", "center", "right"]);
};

/**
 * Проверяет элемент документа (чека) "Картинка (массив пикселей)"
 * @param item Массив пикселей
 * @throws JsonValueNotFoundError, если одно из обязательных полей не найдено
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validatePixelsItem = function(item) {
    exports.mustString(item.pixels, "pixels");
    try {
        Duktape.dec("base64", item.pixels)
    } catch (e) {
        throw new exports.InvalidJsonValueError("pixels", "not-base64-string")
    }
    exports.mustNumber(item.width, "width");
    exports.mustNumberOrMissing(item.scale, "scale");
    exports.mustStringOrMissingValues(item.alignment, "alignment", ["left", "center", "right"]);
};

/**
 * Проверяет структуру данных агента
 * @param agentInfo Данные агента
 * @throws JsonValueNotFoundError, если одно из обязательных полей не найдено
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validateAgentInfo = function(agentInfo) {
    try {
        var agents = exports.mustArrayOrMissing(agentInfo.agents, "agents");
        if (!exports.isMissing(agents)) {
            for (var i = 0; i < agents.length; ++i) {
                try {
                    exports.mustStringValues(agents[i], "", ["bankPayingAgent", "bankPayingSubagent",
                        "payingAgent", "payingSubagent", "attorney",
                        "commissionAgent", "another"]);
                } catch (e) {
                    if (e.name === "InvalidJsonValueError") {
                        throw new exports.InvalidJsonValueError(utils.makeDotPath("agents[" + i + "]", e.path), e.value);
                    } else if (e.name === "InvalidJsonTypeError") {
                        throw new exports.InvalidJsonTypeError(utils.makeDotPath("agents[" + i + "]", e.path), e.expectedType);
                    } else if (e.name === "JsonValueNotFoundError") {
                        throw new exports.JsonValueNotFoundError(utils.makeDotPath("agents[" + i + "]", e.path));
                    } else {
                        throw e;
                    }
                }
            }
        }

        exports.mustObjectOrMissingValidator(agentInfo.payingAgent, "payingAgent", function (payingAgent) {
            exports.mustStringOrMissing(payingAgent.operation, "payingAgent.operation");
            var phones = exports.mustArrayOrMissing(payingAgent.phones, "payingAgent.phones");
            if (!exports.isMissing(phones)) {
                for (var i = 0; i < phones.length; ++i) {
                    try {
                        exports.mustString(phones[i], "");
                    } catch (e) {
                        if (e.name === "InvalidJsonValueError") {
                            throw new exports.InvalidJsonValueError(utils.makeDotPath("payingAgent.phones[" + i + "]", e.path), e.value);
                        } else if (e.name === "InvalidJsonTypeError") {
                            throw new exports.InvalidJsonTypeError(utils.makeDotPath("payingAgent.phones[" + i + "]", e.path), e.expectedType);
                        } else if (e.name === "JsonValueNotFoundError") {
                            throw new exports.JsonValueNotFoundError(utils.makeDotPath("payingAgent.phones[" + i + "]", e.path));
                        } else {
                            throw e;
                        }
                    }
                }
            }
        });

        exports.mustObjectOrMissingValidator(agentInfo.receivePaymentsOperator, "receivePaymentsOperator", function (receivePaymentsOperator) {
            var phones = exports.mustArrayOrMissing(receivePaymentsOperator.phones, "receivePaymentsOperator.phones");
            if (!exports.isMissing(phones)) {
                for (var i = 0; i < phones.length; ++i) {
                    try {
                        exports.mustString(phones[i], "");
                    } catch (e) {
                        if (e.name === "InvalidJsonValueError") {
                            throw new exports.InvalidJsonValueError(utils.makeDotPath("receivePaymentsOperator.phones[" + i + "]", e.path), e.value);
                        } else if (e.name === "InvalidJsonTypeError") {
                            throw new exports.InvalidJsonTypeError(utils.makeDotPath("receivePaymentsOperator.phones[" + i + "]", e.path), e.expectedType);
                        } else if (e.name === "JsonValueNotFoundError") {
                            throw new exports.JsonValueNotFoundError(utils.makeDotPath("receivePaymentsOperator.phones[" + i + "]", e.path));
                        } else {
                            throw e;
                        }
                    }
                }
            }
        });

        exports.mustObjectOrMissingValidator(agentInfo.moneyTransferOperator, "moneyTransferOperator", function (moneyTransferOperator) {
            exports.mustStringOrMissing(moneyTransferOperator.name, "moneyTransferOperator.name");
            exports.mustStringOrMissing(moneyTransferOperator.address, "moneyTransferOperator.address");
            exports.mustStringOrMissing(moneyTransferOperator.vatin, "moneyTransferOperator.vatin");
            var phones = exports.mustArrayOrMissing(moneyTransferOperator.phones, "moneyTransferOperator.phones");
            if (!exports.isMissing(phones)) {
                for (var i = 0; i < phones.length; ++i) {
                    try {
                        exports.mustString(phones[i], "");
                    } catch (e) {
                        if (e.name === "InvalidJsonValueError") {
                            throw new exports.InvalidJsonValueError(utils.makeDotPath("moneyTransferOperator.phones[" + i + "]", e.path), e.value);
                        } else if (e.name === "InvalidJsonTypeError") {
                            throw new exports.InvalidJsonTypeError(utils.makeDotPath("moneyTransferOperator.phones[" + i + "]", e.path), e.expectedType);
                        } else if (e.name === "JsonValueNotFoundError") {
                            throw new exports.JsonValueNotFoundError(utils.makeDotPath("moneyTransferOperator.phones[" + i + "]", e.path));
                        } else {
                            throw e;
                        }
                    }
                }
            }
        });

    } catch (e) {
        if (e.name === "InvalidJsonValueError") {
            throw new exports.InvalidJsonValueError(utils.makeDotPath("agentInfo", e.path), e.value);
        } else if (e.name === "InvalidJsonTypeError") {
            throw new exports.InvalidJsonTypeError(utils.makeDotPath("agentInfo", e.path), e.expectedType);
        } else if (e.name === "JsonValueNotFoundError") {
            throw new exports.JsonValueNotFoundError(utils.makeDotPath("agentInfo", e.path));
        } else {
            throw e;
        }
    }
};

/**
 * Проверяет структуру данных поставщика
 * @param supplierInfo Данные поставщика
 * @throws JsonValueNotFoundError, если одно из обязательных полей не найдено
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validateSupplierInfo = function(supplierInfo) {
    try {
        exports.mustStringOrMissing(supplierInfo.name, "name");
        exports.mustStringOrMissing(supplierInfo.vatin, "vatin");
        var phones = exports.mustArrayOrMissing(supplierInfo.phones, "phones");
        if (!exports.isMissing(phones)) {
            for (var i = 0; i < phones.length; ++i) {
                try {
                    exports.mustString(phones[i], "");
                } catch (e) {
                    if (e.name === "InvalidJsonValueError") {
                        throw new exports.InvalidJsonValueError(utils.makeDotPath("phones[" + i + "]", e.path), e.value);
                    } else if (e.name === "InvalidJsonTypeError") {
                        throw new exports.InvalidJsonTypeError(utils.makeDotPath("phones[" + i + "]", e.path), e.expectedType);
                    } else if (e.name === "JsonValueNotFoundError") {
                        throw new exports.JsonValueNotFoundError(utils.makeDotPath("phones[" + i + "]", e.path));
                    } else {
                        throw e;
                    }
                }
            }
        }
    } catch (e) {
        if (e.name === "InvalidJsonValueError") {
            throw new exports.InvalidJsonValueError(utils.makeDotPath("supplierInfo", e.path), e.value);
        } else if (e.name === "InvalidJsonTypeError") {
            throw new exports.InvalidJsonTypeError(utils.makeDotPath("supplierInfo", e.path), e.expectedType);
        } else if (e.name === "JsonValueNotFoundError") {
            throw new exports.JsonValueNotFoundError(utils.makeDotPath("supplierInfo", e.path));
        } else {
            throw e;
        }
    }
};

/**
 * Проверяет структуру позиции чека
 * @param item Позиция
 * @throws JsonValueNotFoundError, если одно из обязательных полей не найдено
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validatePositionItem = function(item) {
    exports.mustString(item.name, "name");
    exports.mustNumber(item.price, "price");
    exports.mustNumber(item.quantity, "quantity");
    exports.mustNumber(item.amount, "amount");
    exports.mustNumberOrMissing(item.infoDiscountAmount, "infoDiscountAmount");
    exports.mustNumberOrMissing(item.department, "department");
    exports.mustStringOrMissing(item.measurementUnit, "measurementUnit");
    exports.mustBooleanOrMissing(item.piece, "piece");
    try {
        exports.mustStringOrMissingValues(item.paymentMethod, "paymentMethod", Object.keys(utils.PAYMENT_METHODS));
    } catch (e) {
        if (e.name === "InvalidJsonValueError") {
            if (isNaN(parseInt(item.paymentMethod, 10)))
                throw e;
        } else {
            throw e;
        }
    }
    try {
        exports.mustStringOrMissingValues(item.paymentObject, "paymentObject", Object.keys(utils.PAYMENT_OBJECTS));
    } catch (e) {
        if (e.name === "InvalidJsonValueError") {
            var parsed = parseInt(item.paymentObject, 10);
            if (isNaN(parsed))
                throw e;
        } else {
            throw e;
        }
    }

    var code = exports.mustTypesOrMissing(item.nomenclatureCode, "nomenclatureCode", ["object", "string"]);
    if (typeof(code) === "object" && !exports.isMissing(code)) {
        exports.mustStringValues(code.type, "nomenclatureCode.type", ["furs", "medicines", "tobacco", "shoes"]);
        exports.mustStringOrMissing(code.gtin, "nomenclatureCode.gtin");
        exports.mustString(code.serial, "nomenclatureCode.serial");
    }

    if (!exports.isMissing(exports.mustObjectOrMissing(item.markingCode, "markingCode"))) {
        exports.mustString(item.markingCode.mark, "markingCode.mark");
        exports.mustStringOrMissingValues(item.markingCode.type, "markingCode.type", Object.keys(utils.MARKING_CODE_TYPES));
    }

    exports.mustObject(item.tax, "tax");
    exports.mustStringValues(item.tax.type, "tax.type", Object.keys(utils.TAX_TYPES));
    exports.mustNumberOrMissing(item.tax.sum, "tax.sum");

    if (!exports.isMissing(exports.mustObjectOrMissing(item.agentInfo, "agentInfo"))) {
        exports.validateAgentInfo(item.agentInfo);
    }

    if (!exports.isMissing(exports.mustObjectOrMissing(item.supplierInfo, "supplierInfo"))) {
        exports.validateSupplierInfo(item.supplierInfo);
    }

    exports.mustStringOrMissing(item.additionalAttribute, "additionalAttribute");
    exports.mustBooleanOrMissing(item.additionalAttributePrint, "additionalAttributePrint");
    var exciseSum = exports.mustNumberOrMissing(item.exciseSum, "exciseSum");
    if (!exports.isMissing(exciseSum) && Math.sign(exciseSum) < 0) {
        throw new exports.InvalidJsonValueError("exciseSum", exciseSum);
    }
    exports.mustStringOrMissing(item.countryCode, "countryCode");
    exports.mustStringOrMissing(item.customsDeclaration, "customsDeclaration");

    exports.mustNumberOrMissing(item.ucUserParam3, "ucUserParam3");
    exports.mustNumberOrMissing(item.ucUserParam4, "ucUserParam4");
    exports.mustNumberOrMissing(item.ucUserParam5, "ucUserParam5");
    exports.mustNumberOrMissing(item.ucUserParam6, "ucUserParam6");
};

/**
 * Проверяет структуру дополнительного реквизита пользователя
 * @param item Дополнительный реквизит пользователя
 * @throws JsonValueNotFoundError, если одно из обязательных полей не найдено
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validateUserAttributeItem = function(item) {
    exports.mustString(item.name, "name");
    exports.mustString(item.value, "value");
    exports.mustBooleanOrMissing(item.print, "print");
};

/**
 * Проверяет структуру дополнительного реквизита чека (БСО)
 * @param item Дополнительный реквизит чека (БСО)
 * @throws JsonValueNotFoundError, если одно из обязательных полей не найдено
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validateAdditionalAttributeItem = function(item) {
    exports.mustString(item.value, "value");
    exports.mustBooleanOrMissing(item.print, "print");
};

/**
 * Проверяет пре- и пост-элементы документа (нефискальные данные, которые могут печататься
 * до и после документа)
 * @param prePostItems Элементы
 * @param name Название для исключения
 * @throws JsonValueNotFoundError, если одно из обязательных полей не найдено
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validatePrePostItems = function(prePostItems, name) {
    var itemsArray = exports.mustArray(prePostItems, name);
    for (var i = 0; i < itemsArray.length; ++i) {
        try {
            var type = exports.mustString(itemsArray[i].type, "type");
            if (type === "text") {
                exports.validateTextItem(itemsArray[i]);
            } else if (type === "barcode") {
                exports.validateBarcodeItem(itemsArray[i]);
            } else if (type === "pictureFromMemory") {
                exports.validatePictureFromMemoryItem(itemsArray[i]);
            } else if (type === "pixels") {
                exports.validatePixelsItem(itemsArray[i]);
            }
        } catch (e) {
            if (e.name === "InvalidJsonValueError") {
                throw new exports.InvalidJsonValueError(utils.makeDotPath(name + "[" + i + "]", e.path), e.value);
            } else if (e.name === "InvalidJsonTypeError") {
                throw new exports.InvalidJsonTypeError(utils.makeDotPath(name + "[" + i + "]", e.path), e.expectedType);
            } else if (e.name === "JsonValueNotFoundError") {
                throw new exports.JsonValueNotFoundError(utils.makeDotPath(name + "[" + i + "]", e.path));
            } else {
                throw e;
            }
        }
    }
};

/**
 * Проверяет пре-элементы документа (нефискальные данные, которые могут печататься
 * до документа)
 * @param preItems Элементы
 * @throws JsonValueNotFoundError, если одно из обязательных полей не найдено
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validatePreItems = function(preItems) {
    exports.validatePrePostItems(preItems, "preItems");
};

/**
 * Проверяет пост-элементы документа (нефискальные данные, которые могут печататься
 * после документа)
 * @param postItems Элементы
 * @throws JsonValueNotFoundError, если одно из обязательных полей не найдено
 * @throws InvalidJsonTypeError, если у одного из полей некорректный тип
 * @throws InvalidJsonValueError, если у одного из полей некорректное значение
 */
exports.validatePostItems = function(postItems) {
    exports.validatePrePostItems(postItems, "postItems");
};
