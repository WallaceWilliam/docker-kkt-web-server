function execute(task) {
    var organization = {};
    var device = {};
    var ofd = {};

    Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_REG_INFO);
    if (Fptr.fnQueryData() < 0) {
        return Fptr.error();
    }

    organization.name = Fptr.getParamString(1048);
    organization.vatin = Fptr.getParamString(1018);
    organization.email = Fptr.getParamString(1117);
    var taxationTypes = Fptr.getParamInt(1062);
    organization.taxationTypes = [];
    if (taxationTypes & Fptr.LIBFPTR_TT_OSN) {
        organization.taxationTypes.push("osn");
    }
    if (taxationTypes & Fptr.LIBFPTR_TT_USN_INCOME) {
        organization.taxationTypes.push("usnIncome");
    }
    if (taxationTypes & Fptr.LIBFPTR_TT_USN_INCOME_OUTCOME) {
        organization.taxationTypes.push("usnIncomeOutcome");
    }
    if (taxationTypes & Fptr.LIBFPTR_TT_ENVD) {
        organization.taxationTypes.push("envd");
    }
    if (taxationTypes & Fptr.LIBFPTR_TT_ESN) {
        organization.taxationTypes.push("esn");
    }
    if (taxationTypes & Fptr.LIBFPTR_TT_PATENT) {
        organization.taxationTypes.push("patent");
    }
    var agents = Fptr.getParamInt(1057);
    organization.agents = [];
    if (agents & Fptr.LIBFPTR_AT_BANK_PAYING_AGENT) {
        organization.agents.push("bankPayingAgent");
    }
    if (agents & Fptr.LIBFPTR_AT_BANK_PAYING_SUBAGENT) {
        organization.agents.push("bankPayingSubagent");
    }
    if (agents & Fptr.LIBFPTR_AT_PAYING_AGENT) {
        organization.agents.push("payingAgent");
    }
    if (agents & Fptr.LIBFPTR_AT_PAYING_SUBAGENT) {
        organization.agents.push("payingSubagent");
    }
    if (agents & Fptr.LIBFPTR_AT_ATTORNEY) {
        organization.agents.push("attorney");
    }
    if (agents & Fptr.LIBFPTR_AT_COMMISSION_AGENT) {
        organization.agents.push("commissionAgent");
    }
    if (agents & Fptr.LIBFPTR_AT_ANOTHER) {
        organization.agents.push("another");
    }
    organization.address = Fptr.getParamString(1009);

    device.paymentsAddress = Fptr.getParamString(1187);
    device.fnsUrl = Fptr.getParamString(1060);
    device.registrationNumber = Fptr.getParamString(1037);
    device.offlineMode = Fptr.getParamBool(1002);
    device.machineInstallation = Fptr.getParamBool(1221);
    device.bso = Fptr.getParamBool(1110);
    device.encryption = Fptr.getParamBool(1056);
    device.autoMode = Fptr.getParamBool(1001);
    device.machineNumber = Fptr.getParamString(1036);
    device.internet = Fptr.getParamBool(1108);
    device.service = Fptr.getParamBool(1109);
    device.gambling = Fptr.getParamBool(1193);
    device.lottery = Fptr.getParamBool(1126);
    device.excise = Fptr.getParamBool(1207);
    switch (Fptr.getParamInt(1209)) {
        case Fptr.LIBFPTR_FFD_1_0:
            device.ffdVersion = "1.0";
            break;
        case Fptr.LIBFPTR_FFD_1_0_5:
            device.ffdVersion = "1.05";
            break;
        case Fptr.LIBFPTR_FFD_1_1:
            device.ffdVersion = "1.1";
            break;
    }

    ofd.name = Fptr.getParamString(1046);
    ofd.vatin = Fptr.getParamString(1017);

    Fptr.setParam(Fptr.LIBFPTR_PARAM_SETTING_ID, 273);
    Fptr.readDeviceSetting();
    ofd.host = Fptr.getParamString(Fptr.LIBFPTR_PARAM_SETTING_VALUE);

    Fptr.setParam(Fptr.LIBFPTR_PARAM_SETTING_ID, 274);
    Fptr.readDeviceSetting();
    ofd.port = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_SETTING_VALUE);

    Fptr.setParam(Fptr.LIBFPTR_PARAM_SETTING_ID, 275);
    Fptr.readDeviceSetting();
    ofd.dns = Fptr.getParamString(Fptr.LIBFPTR_PARAM_SETTING_VALUE);

    Fptr.setParam(Fptr.LIBFPTR_PARAM_SETTING_ID, 50);
    Fptr.readDeviceSetting();
    switch (Fptr.getParamInt(Fptr.LIBFPTR_PARAM_SETTING_VALUE))
    {
        case Fptr.LIBFPTR_TT_OSN:
            device.defaultTaxationType = "osn";
            break;
        case Fptr.LIBFPTR_TT_USN_INCOME:
            device.defaultTaxationType = "usnIncome";
            break;
        case Fptr.LIBFPTR_TT_USN_INCOME_OUTCOME:
            device.defaultTaxationType = "usnIncomeOutcome";
            break;
        case Fptr.LIBFPTR_TT_ENVD:
            device.defaultTaxationType = "envd";
            break;
        case Fptr.LIBFPTR_TT_ESN:
            device.defaultTaxationType = "esn";
            break;
        case Fptr.LIBFPTR_TT_PATENT:
            device.defaultTaxationType = "patent";
            break;
    }

    Fptr.setParam(Fptr.LIBFPTR_PARAM_SETTING_ID, 276);
    Fptr.readDeviceSetting();
    switch (Fptr.getParamInt(Fptr.LIBFPTR_PARAM_SETTING_VALUE)) {
        case 1:
            device.ofdChannel = "usb";
            break;
        case 2:
            device.ofdChannel = "ethernet";
            break;
        case 3:
            device.ofdChannel = "wifi";
            break;
        case 4:
            device.ofdChannel = "gsm";
            break;
        case 5:
            device.ofdChannel = "proto";
            break;
        default:
            break;
    }

    return Fptr.ok({
        organization: organization,
        device: device,
        ofd: ofd
    });
}
