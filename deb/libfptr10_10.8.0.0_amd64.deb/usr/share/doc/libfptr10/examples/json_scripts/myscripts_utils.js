/**
 * Преобразует дату и время в формат ISO8601
 * @param date {Date} объект даты
 * @returns {string} Строковое представление даты
 */
exports.dateToIsoString = function (date) {
    var tzo = -date.getTimezoneOffset();
    var dif = tzo >= 0 ? '+' : '-';
    var pad = function (num) {
        var norm = Math.floor(Math.abs(num));
        return (norm < 10 ? '0' : '') + norm;
    };
    return date.getUTCFullYear() +
        '-' + pad(date.getUTCMonth() + 1) +
        '-' + pad(date.getUTCDate()) +
        'T' + pad(date.getUTCHours()) +
        ':' + pad(date.getUTCMinutes()) +
        ':' + pad(date.getUTCSeconds()) +
        dif + pad(tzo / 60) +
        ':' + pad(tzo % 60);
};

/**
 * Проверяет, что при возникновении заданной ошибки, отмену чеку не нужно
 * считать провалившейся
 * @param e Код ошибки
 * @returns {boolean} true, если продолжить работу после ошибки
 */
exports.isNormalCancelError = function (e) {
    switch (e) {
        case Fptr.LIBFPTR_ERROR_DENIED_IN_CLOSED_RECEIPT:
            return true;
        case Fptr.LIBFPTR_ERROR_INVALID_MODE:
            return true;
        case Fptr.LIBFPTR_ERROR_MODE_BLOCKED:
        case Fptr.LIBFPTR_ERROR_SHIFT_EXPIRED:
            return true;
        case Fptr.LIBFPTR_ERROR_OPEN_SHIFT_REPORT_INTERRUPTED:
        case Fptr.LIBFPTR_ERROR_CLOSE_FN_REPORT_INTERRUPTED:
        case Fptr.LIBFPTR_ERROR_BLOCKED_BY_REPORT_INTERRUPTION:
        case Fptr.LIBFPTR_ERROR_OFD_EXCHANGE_REPORT_INTERRUPTED:
        case Fptr.LIBFPTR_ERROR_CLOSE_RECEIPT_INTERRUPTED:
        case Fptr.LIBFPTR_ERROR_REGISTRATION_REPORT_INTERRUPTED:
        case Fptr.LIBFPTR_ERROR_REPORT_INTERRUPTED:
            return true;
        case Fptr.LIBFPTR_ERROR_DENIED_BY_LICENSE:
            return true;
        default:
            return false;
    }
};

/**
 * Вспомогательная функция для формирования данных результата
 * фискальных документов
 * @param forReceipt Формировать структуру для чека или нет
 * @returns Объект с фискальными параметрами документа
 */
exports.getFiscalParams = function (forReceipt) {
    var parameters = {};

    if (forReceipt) {
        Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_LAST_RECEIPT);
        if (Fptr.fnQueryData() === 0) {
            parameters.total = Fptr.getParamDouble(Fptr.LIBFPTR_PARAM_RECEIPT_SUM);
            parameters.fiscalDocumentNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_DOCUMENT_NUMBER);
            parameters.fiscalDocumentDateTime = exports.dateToIsoString(Fptr.getParamDateTime(Fptr.LIBFPTR_PARAM_DATE_TIME));
            parameters.fiscalDocumentSign = Fptr.getParamString(Fptr.LIBFPTR_PARAM_FISCAL_SIGN);
        }

    } else {
        Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_LAST_DOCUMENT);
        if (Fptr.fnQueryData() === 0) {
            parameters.fiscalDocumentNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_DOCUMENT_NUMBER);
            parameters.fiscalDocumentDateTime = exports.dateToIsoString(Fptr.getParamDateTime(Fptr.LIBFPTR_PARAM_DATE_TIME));
            parameters.fiscalDocumentSign = Fptr.getParamString(Fptr.LIBFPTR_PARAM_FISCAL_SIGN);
        }
    }

    Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_FN_INFO);
    if (Fptr.fnQueryData() === 0) {
        parameters.fnNumber = Fptr.getParamString(Fptr.LIBFPTR_PARAM_SERIAL_NUMBER);
    }
    Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_TAG_VALUE);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_TAG_NUMBER, 1037);
    if (Fptr.fnQueryData() === 0) {
        parameters.registrationNumber = Fptr.getParamString(Fptr.LIBFPTR_PARAM_TAG_VALUE).trim();
    }
    Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_SHIFT);
    if (Fptr.fnQueryData() === 0) {
        parameters.shiftNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_SHIFT_NUMBER);
        if (forReceipt) {
            parameters.fiscalReceiptNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_RECEIPT_NUMBER);
        }
    }
    Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_TAG_VALUE);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_TAG_NUMBER, 1060);
    if (Fptr.fnQueryData() === 0) {
        parameters.fnsUrl = Fptr.getParamString(Fptr.LIBFPTR_PARAM_TAG_VALUE);
    }
    return parameters;
};

/**
 * Вспомогательная функция для формирования предупреждений при формировании документов
 * @returns Объект с предупреждениями
 */
exports.getWarnings = function () {
    var warnings = {};
    Fptr.setParam(Fptr.LIBFPTR_PARAM_DATA_TYPE, Fptr.LIBFPTR_DT_STATUS);
    if (Fptr.queryData() === 0 && !Fptr.getParamBool(Fptr.LIBFPTR_PARAM_FISCAL))
        warnings.nonFiscal = true;
    Fptr.checkDocumentClosed();
    if (!Fptr.getParamBool(Fptr.LIBFPTR_PARAM_DOCUMENT_PRINTED))
        warnings.notPrinted = true;
    return warnings;
};

/**
 * Список возможных значений версий ФФД для JSON
 */
exports.FFD_VERSIONS = {
    "1.05": Fptr.LIBFPTR_FFD_1_0_5,
    "1.1": Fptr.LIBFPTR_FFD_1_1,
};

/**
 * Список возможных значений систем налогообложения для JSON
 */
exports.TAXATION_TYPES = {
    "osn": Fptr.LIBFPTR_TT_OSN,
    "usnIncome": Fptr.LIBFPTR_TT_USN_INCOME,
    "usnIncomeOutcome": Fptr.LIBFPTR_TT_USN_INCOME_OUTCOME,
    "envd": Fptr.LIBFPTR_TT_ENVD,
    "esn": Fptr.LIBFPTR_TT_ESN,
    "patent": Fptr.LIBFPTR_TT_PATENT
};

/**
 * Список возможных значений признаков агентов для JSON
 */
exports.AGENT_TYPES = {
    "bankPayingAgent": Fptr.LIBFPTR_AT_BANK_PAYING_AGENT,
    "bankPayingSubagent": Fptr.LIBFPTR_AT_BANK_PAYING_SUBAGENT,
    "payingAgent": Fptr.LIBFPTR_AT_PAYING_AGENT,
    "payingSubagent": Fptr.LIBFPTR_AT_PAYING_SUBAGENT,
    "attorney": Fptr.LIBFPTR_AT_ATTORNEY,
    "commissionAgent": Fptr.LIBFPTR_AT_COMMISSION_AGENT,
    "another": Fptr.LIBFPTR_AT_ANOTHER,
};

/**
 * Разбирает налоговую ставку
 * @param value Налоговая ставка для JSON
 * @returns {*} Налоговая ставка для драйвера
 */
exports.parseTaxType = function (value) {
    var r = exports.TAX_TYPES[value];
    if (r === undefined) {
        r = parseInt(value, 10);
        if (isNaN(r))
            return undefined;
    }
    return r;
};

/**
 * Список возможных значений налоговых ставок для JSON
 */
exports.TAX_TYPES = {
    "none": Fptr.LIBFPTR_TAX_NO,
    "vat0": Fptr.LIBFPTR_TAX_VAT0,
    "0": Fptr.LIBFPTR_TAX_VAT0,
    "vat10": Fptr.LIBFPTR_TAX_VAT10,
    "10": Fptr.LIBFPTR_TAX_VAT10,
    "vat110": Fptr.LIBFPTR_TAX_VAT110,
    "110": Fptr.LIBFPTR_TAX_VAT110,
    "vat18": Fptr.LIBFPTR_TAX_VAT18,
    "18": Fptr.LIBFPTR_TAX_VAT18,
    "vat118": Fptr.LIBFPTR_TAX_VAT118,
    "118": Fptr.LIBFPTR_TAX_VAT118,
    "vat20": Fptr.LIBFPTR_TAX_VAT20,
    "20": Fptr.LIBFPTR_TAX_VAT20,
    "vat120": Fptr.LIBFPTR_TAX_VAT120,
    "120": Fptr.LIBFPTR_TAX_VAT120,
};

/**
 * Список возможных значений типов коррекций для JSON
 */
exports.CORRECTION_TYPES = {
    "sellCorrection": Fptr.LIBFPTR_RT_SELL_CORRECTION,
    "sellReturnCorrection": Fptr.LIBFPTR_RT_SELL_RETURN_CORRECTION,
    "buyCorrection": Fptr.LIBFPTR_RT_BUY_CORRECTION,
    "buyReturnCorrection": Fptr.LIBFPTR_RT_BUY_RETURN_CORRECTION
};

/**
 * Список возможных значений типов чеков для JSON
 */
exports.RECEIPT_TYPES = {
    "sell": Fptr.LIBFPTR_RT_SELL,
    "sellReturn": Fptr.LIBFPTR_RT_SELL_RETURN,
    "buy": Fptr.LIBFPTR_RT_BUY,
    "buyReturn": Fptr.LIBFPTR_RT_BUY_RETURN
};

/**
 * Разбирает тип оплаты
 * @param value Тип оплаты для JSON
 * @returns {*} Тип оплаты для драйвера
 */
exports.parsePaymentType = function (value) {
    var r = exports.PAYMENT_TYPES[value];
    if (r === undefined) {
        r = parseInt(value, 10);
        if (isNaN(r))
            return undefined;
    }
    return r;
};

/**
 * Список возможных значений типов оплат для JSON
 */
exports.PAYMENT_TYPES = {
    "cash": Fptr.LIBFPTR_PT_CASH,
    "electronically": Fptr.LIBFPTR_PT_ELECTRONICALLY,
    "prepaid": Fptr.LIBFPTR_PT_PREPAID,
    "credit": Fptr.LIBFPTR_PT_CREDIT,
    "other": Fptr.LIBFPTR_PT_OTHER
};

/**
 * Разбирает признак способа расчета
 * @param value Признак способа расчета для JSON
 * @returns {*} Признак способа расчета для драйвера
 */
exports.parsePaymentMethod = function (value) {
    var r = exports.PAYMENT_METHODS[value];
    if (r === undefined) {
        r = parseInt(value, 10);
        if (isNaN(r))
            return undefined;
    }
    return r;
};

/**
 * Список возможных признака способа расчета для JSON
 */
exports.PAYMENT_METHODS = {
    "fullPrepayment": 1,
    "prepayment": 2,
    "advance": 3,
    "fullPayment": 4,
    "partialPayment": 5,
    "credit": 6,
    "creditPayment": 7
};

/**
 * Разбирает признак предмета расчета
 * @param value Признак предмета расчета для JSON
 * @returns {*} Признак предмета расчета для драйвера
 */
exports.parsePaymentObject = function (value) {
    var r = exports.PAYMENT_OBJECTS[value];
    if (r === undefined) {
        r = parseInt(value, 10);
        if (isNaN(r))
            return undefined;
    }
    return r;
};

/**
 * Список возможных признака предмета расчета для JSON
 */
exports.PAYMENT_OBJECTS = {
    "commodity": 1,
    "excise": 2,
    "job": 3,
    "service": 4,
    "gamblingBet": 5,
    "gamblingPrize": 6,
    "lottery": 7,
    "lotteryPrize": 8,
    "intellectualActivity": 9,
    "payment": 10,
    "agentCommission": 11,
    "composite": 12, // alias для pay
    "pay": 12,
    "another": 13,
    "proprietaryLaw": 14,
    "nonOperatingIncome": 15,
    "insuranceContributions": 16, // alias для otherContributions
    "otherContributions": 16,
    "merchantTax": 17,
    "resortFee": 18,
    "deposit": 19,
    "consumption": 20,
    "soleProprietorCPIContributions": 21,
    "cpiContributions": 22,
    "soleProprietorCMIContributions": 23,
    "cmiContributions": 24,
    "csiContributions": 25,
    "casinoPayment": 26,
};

/**
 * Вспомогательная функция для формирования пути к полю JSON-задания
 * @param path Путь
 * @param newSection Новая секция пути
 * @returns {string} Новый путь
 */
exports.makeDotPath = function (path, newSection) {
    if (newSection) {
        return path + "." + newSection;
    }
    return path;
};


/**
 * Возвращает текущее состояние ошибок обмена с ОФД
 * @returns {object} Ошибки обмена с ОФД
 */
exports.getOfdExchangeErrors = function () {
    var ofdExchangeErrorsInformation = {};

    Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_ERRORS);
    if (Fptr.fnQueryData() === 0) {
        ofdExchangeErrorsInformation.fnCommandCode = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_COMMAND_CODE);
        ofdExchangeErrorsInformation.documentNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_DOCUMENT_NUMBER);

        ofdExchangeErrorsInformation.fn = {
            code: Fptr.getParamInt(Fptr.LIBFPTR_PARAM_FN_ERROR),
            description: Fptr.getParamString(Fptr.LIBFPTR_PARAM_FN_ERROR_TEXT)
        };
        ofdExchangeErrorsInformation.network = {
            code: Fptr.getParamInt(Fptr.LIBFPTR_PARAM_NETWORK_ERROR),
            description: Fptr.getParamString(Fptr.LIBFPTR_PARAM_NETWORK_ERROR_TEXT)
        };
        ofdExchangeErrorsInformation.ofd = {
            code: Fptr.getParamInt(Fptr.LIBFPTR_PARAM_OFD_ERROR),
            description: Fptr.getParamString(Fptr.LIBFPTR_PARAM_OFD_ERROR_TEXT)
        };
    }

    return ofdExchangeErrorsInformation;
};

/**
 * Возвращает результат фискализации документа в ФН
 *
 * @param number Номер документа
 * @param recovery Флаг восстановления
 * @returns {Result} Результат
 */
exports.getFiscalDocumentResult = function (number, recovery) {
    var isLast = false;
    var result = {};
    var parameters = {};
    var warnings = {};

    warnings.recovered = recovery;

    Fptr.setParam(Fptr.LIBFPTR_PARAM_DATA_TYPE, Fptr.LIBFPTR_DT_STATUS);
    if (Fptr.queryData() === 0 && !Fptr.getParamBool(Fptr.LIBFPTR_PARAM_FISCAL))
        warnings.nonFiscal = true;

    Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_LAST_DOCUMENT);
    if (Fptr.fnQueryData() !== 0) {
        if (warnings.nonFiscal) {
            return Fptr.ok({
                fiscalParams: params,
                warnings: warnings
            });
        } else {
            return Fptr.error()
        }
    }

    if (number === undefined || number < 0 || number === Fptr.getParamInt(Fptr.LIBFPTR_PARAM_DOCUMENT_NUMBER)) {
        isLast = true;
        number = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_DOCUMENT_NUMBER)
    } else if (Fptr.getParamInt(Fptr.LIBFPTR_PARAM_DOCUMENT_NUMBER) < number) {
        return Fptr.result(Fptr.LIBFPTR_ERROR_FN_NO_MORE_DATA)
    }
    parameters.fiscalDocumentNumber = number;

    Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_FN_INFO);
    if (Fptr.fnQueryData() === 0) {
        parameters.fnNumber = Fptr.getParamString(Fptr.LIBFPTR_PARAM_SERIAL_NUMBER);
    }

    Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_TAG_VALUE);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_TAG_NUMBER, 1037);
    if (Fptr.fnQueryData() === 0) {
        parameters.registrationNumber = Fptr.getParamString(Fptr.LIBFPTR_PARAM_TAG_VALUE).trim();
    }

    Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_TAG_VALUE);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_TAG_NUMBER, 1060);
    if (Fptr.fnQueryData() === 0) {
        parameters.fnsUrl = Fptr.getParamString(Fptr.LIBFPTR_PARAM_TAG_VALUE);
    }

    Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_DOCUMENT_BY_NUMBER);
    Fptr.setParam(Fptr.LIBFPTR_PARAM_DOCUMENT_NUMBER, parameters.fiscalDocumentNumber);
    var isReceipt = false, isCloseShift = false, isExchangeStatus = false;
    if (Fptr.fnQueryData() === 0) {
        parameters.fiscalDocumentNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_DOCUMENT_NUMBER);
        parameters.fiscalDocumentDateTime = exports.dateToIsoString(Fptr.getParamDateTime(Fptr.LIBFPTR_PARAM_DATE_TIME));
        parameters.fiscalDocumentSign = Fptr.getParamString(Fptr.LIBFPTR_PARAM_FISCAL_SIGN);

        switch (Fptr.getParamInt(Fptr.LIBFPTR_PARAM_FN_DOCUMENT_TYPE)) {
            case Fptr.LIBFPTR_FN_DOC_RECEIPT:
            case Fptr.LIBFPTR_FN_DOC_BSO:
            case Fptr.LIBFPTR_FN_DOC_CORRECTION:
            case Fptr.LIBFPTR_FN_DOC_BSO_CORRECTION:
                isReceipt = true;
                parameters.total = Fptr.getParamDouble(1020);
                break;
            case Fptr.LIBFPTR_FN_DOC_CLOSE_SHIFT:
                isCloseShift = true;
                parameters.shiftNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_SHIFT_NUMBER);
                break;
            case Fptr.LIBFPTR_FN_DOC_OPEN_SHIFT:
                parameters.shiftNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_SHIFT_NUMBER);
                break;
            case Fptr.LIBFPTR_FN_DOC_EXCHANGE_STATUS:
                isExchangeStatus = true;
                break;
        }
    }

    if (isLast) {
        Fptr.checkDocumentClosed();
        if (!Fptr.getParamBool(Fptr.LIBFPTR_PARAM_DOCUMENT_PRINTED))
            warnings.notPrinted = true;

        Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_SHIFT);
        if (Fptr.fnQueryData() === 0) {
            parameters.shiftNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_SHIFT_NUMBER);
            if (isReceipt) {
                parameters.fiscalReceiptNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_RECEIPT_NUMBER);
            }
        }
        if (isCloseShift) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_SHIFT);
            if (Fptr.fnQueryData() === 0) {
                parameters.receiptsCount = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_RECEIPT_NUMBER);
            }
        }
        if (isExchangeStatus) {
            var state = {};

            Fptr.setParam(Fptr.LIBFPTR_PARAM_FN_DATA_TYPE, Fptr.LIBFPTR_FNDT_OFD_EXCHANGE_STATUS);
            if (Fptr.fnQueryData() === 0) {
                state.notSentCount = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_DOCUMENTS_COUNT);
                state.notSentFirstDocDateTime = exports.dateToIsoString(Fptr.getParamDateTime(Fptr.LIBFPTR_PARAM_DATE_TIME));
                state.notSentFirstDocNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_DOCUMENT_NUMBER);
            }

            result.errors = exports.getOfdExchangeErrors();
            result.status = state;
        }
    } else {
        var ofdExchangeState = {};

        function readNextRecord(recordsID) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_RECORDS_ID, recordsID);
            return Fptr.readNextRecord();
        }

        if (isReceipt) {
            parameters.shiftNumber = 0;
            parameters.fiscalReceiptNumber = 0;
        } else if (isCloseShift) {
            parameters.receiptsCount = 0;
        } else if (isExchangeStatus) {
            parameters.shiftNumber = 0;
            ofdExchangeState.notSentCount = 0;
            ofdExchangeState.notSentFirstDocNumber = 0;
            ofdExchangeState.notSentFirstDocDateTime = exports.dateToIsoString(new Date(0));
        } else {
            parameters.shiftNumber = 0;
        }

        for (var i = 0; i < 3; ++i) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_RECORDS_TYPE, Fptr.LIBFPTR_RT_FN_DOCUMENT_TLVS);
            Fptr.setParam(Fptr.LIBFPTR_PARAM_DOCUMENT_NUMBER, parameters.fiscalDocumentNumber);
            var r = Fptr.beginReadRecords();
            recordsID = Fptr.getParamString(Fptr.LIBFPTR_PARAM_RECORDS_ID);
            if (r === 0) {
                while (readNextRecord(recordsID) === Fptr.LIBFPTR_OK) {
                    var tagNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_TAG_NUMBER);
                    switch (tagNumber) {
                        case 1038:
                            parameters.shiftNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_TAG_VALUE);
                            break;
                        case 1042:
                            parameters.fiscalReceiptNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_TAG_VALUE);
                            break;
                        case 1097:
                            ofdExchangeState.notSentCount = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_TAG_VALUE) + 1;
                            break;
                        case 1116:
                            ofdExchangeState.notSentFirstDocNumber = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_TAG_VALUE);
                            break;
                        case 1098:
                            ofdExchangeState.notSentFirstDocDateTime = exports.dateToIsoString(Fptr.getParamDateTime(Fptr.LIBFPTR_PARAM_TAG_VALUE));
                            break;
                        case 1118:
                            parameters.receiptsCount = Fptr.getParamInt(Fptr.LIBFPTR_PARAM_TAG_VALUE);
                            break;
                    }
                }

                Fptr.setParam(Fptr.LIBFPTR_PARAM_RECORDS_ID, recordsID);
                Fptr.endReadRecords();

                break;
            } else if (Fptr.error().error === Fptr.LIBFPTR_ERROR_FN_QUERY_INTERRUPTED) {
                sleep(300);
            }
        }

        if (isExchangeStatus) {
            result.errors = exports.getOfdExchangeErrors();
            result.status = ofdExchangeState;
        }
    }

    result.fiscalParams = parameters;
    result.warnings = warnings;
    return Fptr.ok(result);
};


/**
 * Список возможных значений типов марки
 */
exports.MARKING_CODE_TYPES = {
    "other": Fptr.LIBFPTR_MCT_OTHER,
    "egais20": Fptr.LIBFPTR_MCT_EGAIS_20,
    "egais30": Fptr.LIBFPTR_MCT_EGAIS_30
};

/**
 * Разбирает налоговую ставку
 * @param value Налоговая ставка для JSON
 * @returns {*} Налоговая ставка для драйвера
 */
exports.parseMarkingCodeType = function (value) {
    var r = exports.MARKING_CODE_TYPES[value];
    if (r === undefined) {
        r = parseInt(value, 10);
        if (isNaN(r))
            return undefined;
    }
    return r;
};
